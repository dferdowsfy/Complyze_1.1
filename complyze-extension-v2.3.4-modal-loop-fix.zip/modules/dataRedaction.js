// Data redaction module for Complyze extension
import { REDACTION_PATTERNS, AI_RISK_PATTERNS } from './config.js';

export class DataRedactor {
  /**
   * Remove sensitive data from prompt using configured patterns
   * This replaces the massive 800+ line removeSensitiveData method
   */
  static removeSensitiveData(prompt) {
    const sensitiveDataRemoved = [];
    const complianceFrameworks = [];
    const aiRiskIndicators = [];
    let cleaned = prompt;

    // Process redaction patterns
    Object.entries(REDACTION_PATTERNS).forEach(([key, pattern]) => {
      const matches = prompt.match(pattern.regex);
      if (matches) {
        matches.forEach(match => {
          const displayValue = pattern.truncate 
            ? `${match.substring(0, pattern.truncate)}...`
            : match;
          sensitiveDataRemoved.push(`${pattern.type}: ${displayValue}`);
        });
        cleaned = cleaned.replace(pattern.regex, pattern.replacement);
      }
    });

    // Process AI risk patterns
    Object.entries(AI_RISK_PATTERNS).forEach(([key, pattern]) => {
      if (pattern.regex.test(prompt)) {
        aiRiskIndicators.push(pattern.type);
        cleaned = cleaned.replace(pattern.regex, pattern.replacement);
      }
    });

    // Determine compliance frameworks
    if (sensitiveDataRemoved.some(item => 
      item.includes('Medical') || item.includes('Patient') || item.includes('MRN')
    )) {
      complianceFrameworks.push('HIPAA');
    }

    if (sensitiveDataRemoved.some(item => 
      item.includes('Social Security') || item.includes('Credit card')
    )) {
      complianceFrameworks.push('PCI DSS');
    }

    if (sensitiveDataRemoved.some(item => 
      item.includes('Email') || item.includes('Phone')
    )) {
      complianceFrameworks.push('GDPR');
    }

    return {
      cleaned,
      sensitiveDataRemoved,
      complianceFrameworks,
      aiRiskIndicators
    };
  }

  /**
   * Analyze prompt intent efficiently
   */
  static analyzePromptIntent(prompt) {
    const lowerPrompt = prompt.toLowerCase();
    
    const intentPatterns = {
      creation: ['create', 'generate', 'write', 'make', 'build', 'design', 'compose'],
      analysis: ['analyze', 'review', 'examine', 'evaluate', 'assess', 'check'],
      explanation: ['explain', 'describe', 'clarify', 'help me understand', 'what is'],
      modification: ['edit', 'modify', 'change', 'update', 'revise', 'improve'],
      question: ['?', 'how', 'what', 'why', 'when', 'where', 'which']
    };

    for (const [intent, keywords] of Object.entries(intentPatterns)) {
      if (keywords.some(keyword => lowerPrompt.includes(keyword))) {
        return intent;
      }
    }

    return 'general';
  }

  /**
   * Calculate risk level based on findings
   */
  static calculateRiskLevel(sensitiveDataRemoved, aiRiskIndicators) {
    let score = 0;
    
    // Base risk from sensitive data
    score += sensitiveDataRemoved.length * 2;
    
    // Higher risk for specific data types
    const highRiskTypes = ['Social Security', 'Medical', 'Credit card', 'API key'];
    const highRiskCount = sensitiveDataRemoved.filter(item => 
      highRiskTypes.some(type => item.includes(type))
    ).length;
    score += highRiskCount * 3;
    
    // AI risk indicators
    score += aiRiskIndicators.length * 5;
    
    // Determine risk level
    if (score >= 15) return 'high';
    if (score >= 8) return 'medium';
    if (score >= 3) return 'low';
    return 'none';
  }

  /**
   * Generate a safe prompt replacement
   */
  static generateSafePrompt(originalPrompt) {
    const { cleaned, sensitiveDataRemoved } = this.removeSensitiveData(originalPrompt);
    
    if (sensitiveDataRemoved.length === 0) {
      return originalPrompt;
    }

    // Natural language replacement without [REDACTED] placeholders
    let safePrompt = cleaned;
    
    // Replace redaction markers with natural alternatives
    const replacements = {
      '[EMAIL_REDACTED]': 'an email address',
      '[SSN_REDACTED]': 'a social security number',
      '[CREDIT_CARD_REDACTED]': 'a payment card number',
      '[PHONE_REDACTED]': 'a phone number',
      '[IP_ADDRESS_REDACTED]': 'an IP address',
      '[BANK_ACCOUNT_REDACTED]': 'a bank account number',
      '[PASSPORT_REDACTED]': 'a passport number',
      '[DRIVERS_LICENSE_REDACTED]': 'a driver\'s license number',
      '[MRN_REDACTED]': 'a medical record number',
      '[PATIENT_ID_REDACTED]': 'a patient identifier',
      '[MAC_ADDRESS_REDACTED]': 'a MAC address',
      '[OPENAI_API_KEY_REDACTED]': 'an API key',
      '[OPENROUTER_API_KEY_REDACTED]': 'an API key',
      '[ANTHROPIC_API_KEY_REDACTED]': 'an API key',
      '[GOOGLE_API_KEY_REDACTED]': 'an API key',
      '[AWS_ACCESS_KEY_REDACTED]': 'an AWS access key',
      '[GITHUB_TOKEN_REDACTED]': 'a GitHub token',
      '[STRIPE_API_KEY_REDACTED]': 'a Stripe API key',
      '[API_KEY_REDACTED]': 'an API key',
      '[TOKEN_REDACTED]': 'an authentication token',
      '[BEARER_TOKEN_REDACTED]': 'a bearer token',
      '[JWT_TOKEN_REDACTED]': 'a JWT token',
      '[DB_CONNECTION_REDACTED]': 'a database connection string'
    };

    Object.entries(replacements).forEach(([marker, replacement]) => {
      safePrompt = safePrompt.replace(new RegExp(marker.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), replacement);
    });

    return safePrompt;
  }
} 
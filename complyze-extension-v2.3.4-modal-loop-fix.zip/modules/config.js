// Configuration module for Complyze extension
export const CONFIG = {
  API: {
    PRODUCTION_BASE: 'https://complyze.co/api',
    PRODUCTION_DASHBOARD: 'https://complyze.co/dashboard',
    OPENROUTER: {
      BASE_URL: 'https://openrouter.ai/api/v1/chat/completions',
      MODEL: 'google/gemini-2.5-pro-preview'
    }
  },
  
  TIMEOUTS: {
    TOKEN_VERIFICATION: 10000,
    API_REQUEST: 30000,
    PORT_DETECTION: 1000
  },
  
  INTERVALS: {
    TOKEN_VERIFICATION: 15 * 60 * 1000 // 15 minutes
  }
};

// Sensitive data redaction patterns
export const REDACTION_PATTERNS = {
  email: {
    regex: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g,
    replacement: '[EMAIL_REDACTED]',
    type: 'Email address'
  },
  ssn: {
    regex: /\b\d{3}-\d{2}-\d{4}\b/g,
    replacement: '[SSN_REDACTED]',
    type: 'Social Security Number'
  },
  ssnNoHyphen: {
    regex: /\b\d{9}\b/g,
    replacement: '[SSN_REDACTED]',
    type: 'Social Security Number'
  },
  creditCard: {
    regex: /\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/g,
    replacement: '[CREDIT_CARD_REDACTED]',
    type: 'Credit card number'
  },
  phone: {
    regex: /\b\d{3}-\d{3}-\d{4}\b/g,
    replacement: '[PHONE_REDACTED]',
    type: 'Phone number'
  },
  phoneParen: {
    regex: /\b\(\d{3}\)\s?\d{3}-\d{4}\b/g,
    replacement: '[PHONE_REDACTED]',
    type: 'Phone number'
  },
  ipAddress: {
    regex: /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g,
    replacement: '[IP_ADDRESS_REDACTED]',
    type: 'IP address'
  },
  bankAccount: {
    regex: /\b\d{10,12}\b/g,
    replacement: '[BANK_ACCOUNT_REDACTED]',
    type: 'Bank account number'
  },
  passport: {
    regex: /\b[a-z]{1,2}\d{6,8}\b/gi,
    replacement: '[PASSPORT_REDACTED]',
    type: 'Passport number'
  },
  driversLicense: {
    regex: /\b[a-z]\d{7,8}\b/gi,
    replacement: '[DRIVERS_LICENSE_REDACTED]',
    type: "Driver's license"
  },
  mrn: {
    regex: /\bmrn[\s:]*\d{6,10}/gi,
    replacement: '[MRN_REDACTED]',
    type: 'Medical record number'
  },
  patientId: {
    regex: /\bpatient[\s-_]?id[\s:]*\d+/gi,
    replacement: '[PATIENT_ID_REDACTED]',
    type: 'Patient ID'
  },
  macAddress: {
    regex: /\b[0-9a-f]{2}[:-][0-9a-f]{2}[:-][0-9a-f]{2}[:-][0-9a-f]{2}[:-][0-9a-f]{2}[:-][0-9a-f]{2}\b/gi,
    replacement: '[MAC_ADDRESS_REDACTED]',
    type: 'MAC address'
  },
  openaiKey: {
    regex: /\bsk-[a-zA-Z0-9]{48,64}\b/g,
    replacement: '[OPENAI_API_KEY_REDACTED]',
    type: 'OpenAI API key',
    truncate: 10
  },
  openrouterKey: {
    regex: /\bsk-or-v1-[a-f0-9]{64}\b/g,
    replacement: '[OPENROUTER_API_KEY_REDACTED]',
    type: 'OpenRouter API key',
    truncate: 15
  },
  anthropicKey: {
    regex: /\bsk-ant-[a-zA-Z0-9\-_]{95,105}\b/g,
    replacement: '[ANTHROPIC_API_KEY_REDACTED]',
    type: 'Anthropic API key',
    truncate: 10
  },
  googleKey: {
    regex: /\bAIza[a-zA-Z0-9\-_]{35}\b/g,
    replacement: '[GOOGLE_API_KEY_REDACTED]',
    type: 'Google API key',
    truncate: 10
  },
  awsAccessKey: {
    regex: /\bAKIA[a-zA-Z0-9]{16}\b/g,
    replacement: '[AWS_ACCESS_KEY_REDACTED]',
    type: 'AWS Access Key',
    truncate: 8
  },
  githubToken: {
    regex: /\bghp_[a-zA-Z0-9]{36}\b/g,
    replacement: '[GITHUB_TOKEN_REDACTED]',
    type: 'GitHub Token',
    truncate: 8
  },
  stripeKey: {
    regex: /\b(?:sk|pk)_(?:live|test)_[a-zA-Z0-9]{24,}\b/g,
    replacement: '[STRIPE_API_KEY_REDACTED]',
    type: 'Stripe API key',
    truncate: 12
  },
  genericApiKey: {
    regex: /\bapi[\s_-]?key[\s:=]+[a-z0-9\-_]{16,}/gi,
    replacement: '[API_KEY_REDACTED]',
    type: 'API key',
    truncate: 20
  },
  token: {
    regex: /\btoken[\s:=]+[a-z0-9\-_\.]{20,}/gi,
    replacement: '[TOKEN_REDACTED]',
    type: 'Auth token',
    truncate: 20
  },
  bearerToken: {
    regex: /\bbearer\s+[a-z0-9\-_\.]{20,}/gi,
    replacement: '[BEARER_TOKEN_REDACTED]',
    type: 'Bearer token',
    truncate: 20
  },
  jwtToken: {
    regex: /\beyJ[a-zA-Z0-9\-_]+\.[a-zA-Z0-9\-_]+\.[a-zA-Z0-9\-_]+/g,
    replacement: '[JWT_TOKEN_REDACTED]',
    type: 'JWT Token',
    truncate: 20
  },
  dbConnection: {
    regex: /\b(?:mongodb|mysql|postgresql|redis):\/\/[^\s]+/gi,
    replacement: '[DB_CONNECTION_REDACTED]',
    type: 'Database connection',
    truncate: 20
  }
};

// AI Risk patterns
export const AI_RISK_PATTERNS = {
  promptInjection: {
    regex: /ignore\s+(previous|all)\s+instructions/gi,
    replacement: '[PROMPT_INJECTION_DETECTED]',
    type: 'Prompt injection attempt detected'
  },
  instructionOverride: {
    regex: /forget\s+(everything|all)\s+(above|before)/gi,
    replacement: '[INSTRUCTION_OVERRIDE_DETECTED]',
    type: 'System instruction override attempt'
  },
  jailbreak: {
    regex: /\bjailbreak/gi,
    replacement: '[JAILBREAK_ATTEMPT]',
    type: 'Jailbreak attempt detected'
  },
  danMode: {
    regex: /\bdan\s+mode/gi,
    replacement: '[DAN_MODE_ATTEMPT]',
    type: 'DAN (Do Anything Now) mode attempt'
  }
};

// Message types
export const MESSAGE_TYPES = {
  DEBUG_TEST: 'debug_test',
  ANALYZE_PROMPT: 'analyze_prompt',
  ANALYZE_PROMPT_REALTIME: 'analyze_prompt_realtime',
  LOGIN: 'login',
  SIGNUP: 'signup',
  LOGOUT: 'logout',
  SYNC_FROM_WEBSITE: 'sync_from_website',
  UPDATE_REDACTION_SETTINGS: 'update_redaction_settings',
  GET_AUTH_STATUS: 'get_auth_status',
  SET_AUTH_DATA: 'set_auth_data',
  GET_DASHBOARD_URL: 'get_dashboard_url'
}; 
// Complyze Prompt Interceptor - Real-time Blocking & Optimization Modal
// This script intercepts form submissions and shows optimization modal

class ComplyzePromptInterceptor {
  constructor() {
    this.isActive = true;
    this.currentPlatform = this.detectPlatform();
    this.selectors = this.getPlatformSelectors();
    this.interceptedElements = new Set();
    this.optimizationModal = null;
    this.currentPromptData = null;
    this.isModalVisible = false;
    this.isProcessing = false;
    
    this.init();
  }

  init() {
    console.log('🛡️ Complyze Prompt Interceptor initializing for:', this.currentPlatform);
    
    // Start monitoring
    this.startMonitoring();
    
    // Create modal HTML
    this.createOptimizationModal();
    
    // Listen for optimization results from background script
    this.setupMessageListeners();
    
    console.log('✅ Prompt Interceptor ready');
  }

  detectPlatform() {
    const hostname = window.location.hostname.toLowerCase();
    
    if (hostname.includes('openai.com') || hostname.includes('chatgpt.com')) {
      return 'ChatGPT';
    } else if (hostname.includes('claude.ai')) {
      return 'Claude';
    } else if (hostname.includes('gemini.google.com') || hostname.includes('bard.google.com')) {
      return 'Gemini';
    } else if (hostname.includes('poe.com')) {
      return 'Poe';
    } else if (hostname.includes('character.ai')) {
      return 'Character.AI';
    }
    
    return 'Unknown';
  }

  getPlatformSelectors() {
    const selectors = {
      'ChatGPT': {
        promptInput: 'textarea[data-id], div[contenteditable="true"]#prompt-textarea, textarea[placeholder*="Message"], div[contenteditable="true"][data-testid]',
        submitButton: 'button[data-testid="send-button"], button[aria-label*="Send"], button:has(svg[data-icon="send"]), form button[type="submit"]',
        form: 'form:has(textarea), form:has(div[contenteditable="true"])'
      },
      'Claude': {
        promptInput: 'div[contenteditable="true"], textarea[placeholder*="Talk to Claude"], div[data-testid="composer-input"], div[role="textbox"]',
        submitButton: 'button[aria-label="Send Message"], button:has(svg[data-icon="send"]), button[data-testid="send-button"]',
        form: 'form:has(div[contenteditable="true"]), div:has(button[aria-label="Send Message"])'
      },
      'Gemini': {
        promptInput: 'textarea[data-testid="chat-input"], div[contenteditable="true"], textarea[placeholder*="Enter a prompt"]',
        submitButton: 'button[data-testid="send-button"], button[aria-label*="Send"], button:has(svg)',
        form: 'form:has(textarea), div:has(button[data-testid="send-button"])'
      },
      'Poe': {
        promptInput: 'textarea[placeholder*="Send a message"], div[contenteditable="true"]',
        submitButton: 'button[class*="send"], button:has(svg[data-icon="send"])',
        form: 'form:has(textarea)'
      },
      'Character.AI': {
        promptInput: 'textarea[placeholder*="Type a message"], div[contenteditable="true"]',
        submitButton: 'button[type="submit"], button:has(svg)',
        form: 'form:has(textarea)'
      }
    };

    return selectors[this.currentPlatform] || selectors['ChatGPT'];
  }

  startMonitoring() {
    // Monitor for new elements (dynamic content)
    const observer = new MutationObserver((mutations) => {
      mutations.forEach(mutation => {
        if (mutation.type === 'childList') {
          mutation.addedNodes.forEach(node => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              this.interceptNewElements(node);
            }
          });
        }
      });
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    // Initial scan
    this.interceptExistingElements();
    
    // Periodic re-scan for dynamic content
    setInterval(() => {
      this.interceptExistingElements();
    }, 2000);
  }

  interceptExistingElements() {
    // Find and intercept submit buttons
    const submitButtons = document.querySelectorAll(this.selectors.submitButton);
    
    submitButtons.forEach(button => {
      if (!this.interceptedElements.has(button)) {
        this.interceptSubmitButton(button);
        this.interceptedElements.add(button);
      }
    });

    // Find and intercept forms
    const forms = document.querySelectorAll(this.selectors.form);
    
    forms.forEach(form => {
      if (!this.interceptedElements.has(form)) {
        this.interceptForm(form);
        this.interceptedElements.add(form);
      }
    });
  }

  interceptNewElements(element) {
    // Check if the new element or its children contain submit buttons
    const submitButtons = element.querySelectorAll ? 
      element.querySelectorAll(this.selectors.submitButton) : [];
    
    submitButtons.forEach(button => {
      if (!this.interceptedElements.has(button)) {
        this.interceptSubmitButton(button);
        this.interceptedElements.add(button);
      }
    });

    // Check for forms
    const forms = element.querySelectorAll ? 
      element.querySelectorAll(this.selectors.form) : [];
    
    forms.forEach(form => {
      if (!this.interceptedElements.has(form)) {
        this.interceptForm(form);
        this.interceptedElements.add(form);
      }
    });

    // Check if the element itself is a submit button or form
    if (element.matches && element.matches(this.selectors.submitButton)) {
      if (!this.interceptedElements.has(element)) {
        this.interceptSubmitButton(element);
        this.interceptedElements.add(element);
      }
    }

    if (element.matches && element.matches(this.selectors.form)) {
      if (!this.interceptedElements.has(element)) {
        this.interceptForm(element);
        this.interceptedElements.add(element);
      }
    }
  }

  interceptSubmitButton(button) {
    console.log('🔒 Intercepting submit button:', button);
    
    // Store original click handler
    const originalOnClick = button.onclick;
    
    // Override click event
    button.addEventListener('click', (event) => {
      this.handleSubmitAttempt(event, button, originalOnClick);
    }, true); // Use capture phase to intercept early

    // Override form submission if button is in a form
    const form = button.closest('form');
    if (form) {
      this.interceptForm(form);
    }
  }

  interceptForm(form) {
    console.log('🔒 Intercepting form:', form);
    
    // Store original submit handler
    const originalOnSubmit = form.onsubmit;
    
    // Override submit event
    form.addEventListener('submit', (event) => {
      this.handleSubmitAttempt(event, form, originalOnSubmit);
    }, true); // Use capture phase
  }

  async handleSubmitAttempt(event, element, originalHandler) {
    console.log('🚨 Submit attempt intercepted!', {
      element: element.tagName,
      platform: this.currentPlatform,
      timestamp: new Date().toISOString(),
      isModalVisible: this.isModalVisible,
      isProcessing: this.isProcessing
    });

    if (this.isModalVisible || this.isProcessing) {
      console.log('⚠️ Modal already visible or processing, preventing duplicate popup');
      event.preventDefault();
      event.stopImmediatePropagation();
      return;
    }

    // Get the prompt text
    const promptText = this.extractPromptText();
    
    if (!promptText || promptText.trim().length < 4) {
      console.log('📝 Prompt too short, allowing submission');
      return; // Allow submission for very short prompts
    }

    console.log('📝 Extracted prompt:', promptText.substring(0, 100) + '...');

    // Immediately prevent the default action
    event.preventDefault();
    event.stopImmediatePropagation();

    // Quick sensitive data check
    if (this.shouldTriggerOptimization(promptText)) {
      console.log('🚨 SENSITIVE DATA DETECTED - Triggering optimization modal');
      
      this.isProcessing = true;
      
      // Disable send button and show loading state
      this.disableSubmitButtons();
      this.showOptimizationLoading();
      
      // Request optimization from background script
      await this.requestOptimization(promptText, element, originalHandler);
    } else {
      console.log('✅ No sensitive data detected, allowing submission');
      // Allow original submission
      this.executeOriginalSubmit(element, originalHandler);
    }
  }

  extractPromptText() {
    // Try multiple methods to get the prompt text
    const inputs = document.querySelectorAll(this.selectors.promptInput);
    
    for (const input of inputs) {
      let text = '';
      
      if (input.tagName.toLowerCase() === 'textarea') {
        text = input.value;
      } else if (input.contentEditable === 'true') {
        text = input.innerText || input.textContent;
      }
      
      if (text && text.trim().length > 0) {
        return text.trim();
      }
    }
    
    return '';
  }

  shouldTriggerOptimization(prompt) {
    // Enhanced detection patterns (same as background script)
    const sensitivePatterns = [
      // Email addresses
      /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g,
      // SSN
      /\b\d{3}-\d{2}-\d{4}\b/g,
      /\b\d{9}\b/g,
      // Phone numbers
      /\b\d{3}-\d{3}-\d{4}\b/g,
      /\b\(\d{3}\)\s?\d{3}-\d{4}\b/g,
      // Credit cards
      /\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/g,
      // IP addresses
      /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g,
      // API Keys
      /\bsk-[a-zA-Z0-9]{48,64}\b/g,
      /\bsk-or-v1-[a-f0-9]{64}\b/g,
      /\bsk-ant-[a-zA-Z0-9\-_]{95,105}\b/g,
      /\bAIza[a-zA-Z0-9\-_]{35}\b/g,
      /\bAKIA[a-zA-Z0-9]{16}\b/g,
      // Generic API patterns
      /\bapi[\s_-]?key[\s:=]+[a-z0-9\-_]{16,}/gi,
      /\btoken[\s:=]+[a-z0-9\-_\.]{20,}/gi,
      /\bbearer\s+[a-z0-9\-_\.]{20,}/gi
    ];

    const promptIndicators = [
      /\b(how to|please|can you|help me|explain|analyze|write|create|generate)\b/i
    ];

    // Check for sensitive data
    const hasSensitiveData = sensitivePatterns.some(pattern => pattern.test(prompt));
    
    // Check for prompt-like content
    const isPromptLike = promptIndicators.some(pattern => pattern.test(prompt)) && prompt.length > 10;

    return hasSensitiveData || (isPromptLike && prompt.length > 20);
  }

  async requestOptimization(promptText, element, originalHandler) {
    try {
      // Store current context
      this.currentPromptData = {
        originalPrompt: promptText,
        element: element,
        originalHandler: originalHandler,
        timestamp: new Date().toISOString()
      };

      // Send to background script for AI optimization
      const response = await chrome.runtime.sendMessage({
        type: 'analyze_prompt',
        payload: {
          prompt: promptText,
          platform: this.currentPlatform,
          url: window.location.href,
          timestamp: new Date().toISOString(),
          triggerOptimization: true // Request optimization
        }
      });

      console.log('🤖 Optimization response:', response);

      if (response && response.success && response.optimizedPrompt) {
        this.showOptimizationModal(response);
      } else {
        console.error('❌ Optimization failed, allowing original submission');
        this.resetModalState();
        this.executeOriginalSubmit(element, originalHandler);
      }
    } catch (error) {
      console.error('❌ Error requesting optimization:', error);
      this.resetModalState();
      this.executeOriginalSubmit(element, originalHandler);
    }
  }

  showOptimizationLoading() {
    if (!this.optimizationModal) return;
    
    this.isModalVisible = true;
    
    this.optimizationModal.style.display = 'flex';
    this.optimizationModal.innerHTML = `
      <div class="complyze-modal-content loading">
        <button class="complyze-minimize-btn" onclick="window.complyzeInterceptor.quickDismiss()" title="Quick dismiss">
          <span class="minimize-icon">−</span>
          <span class="minimize-text">Minimize</span>
        </button>
        
        <div class="complyze-loading-spinner"></div>
        <h3>🔒 Securing Your Prompt</h3>
        <p>Complyze detected sensitive information in your prompt and is creating a safer version...</p>
        <div class="complyze-progress-bar">
          <div class="complyze-progress-fill"></div>
        </div>
        <p class="complyze-loading-text">Analyzing for PII, credentials, and security risks...</p>
        <div class="complyze-submit-disabled-notice">
          <p>🔒 Send button is disabled until you choose a security option</p>
        </div>
      </div>
    `;
  }

  showOptimizationModal(optimizationResult) {
    if (!this.optimizationModal || !this.currentPromptData) return;

    const modal = this.optimizationModal;
    const originalPrompt = this.currentPromptData.originalPrompt;
    const optimizedPrompt = optimizationResult.optimizedPrompt;
    const improvements = optimizationResult.optimizationDetails?.improvements || [];

    this.isModalVisible = true;
    this.isProcessing = false;

    modal.innerHTML = `
      <div class="complyze-modal-content">
        <button class="complyze-minimize-btn" onclick="window.complyzeInterceptor.quickDismiss()" title="Quick dismiss">
          <span class="minimize-icon">−</span>
          <span class="minimize-text">Minimize</span>
        </button>
        
        <div class="complyze-modal-header">
          <h3>🛡️ Prompt Security Optimization</h3>
          <p>Complyze detected sensitive information and created a safer version:</p>
        </div>
        
        <div class="complyze-prompt-comparison">
          <div class="complyze-prompt-section">
            <h4>⚠️ Original Prompt (Contains Sensitive Data)</h4>
            <div class="complyze-prompt-box original">
              <pre>${this.escapeHtml(originalPrompt)}</pre>
            </div>
          </div>
          
          <div class="complyze-prompt-section">
            <h4>✅ Optimized Prompt (Secure)</h4>
            <div class="complyze-prompt-box optimized">
              <pre>${this.escapeHtml(optimizedPrompt)}</pre>
            </div>
          </div>
        </div>

        ${improvements.length > 0 ? `
        <div class="complyze-improvements">
          <h4>🚀 Improvements Made:</h4>
          <ul>
            ${improvements.map(improvement => `<li>${this.escapeHtml(improvement)}</li>`).join('')}
          </ul>
        </div>
        ` : ''}

        <div class="complyze-modal-actions">
          <button class="complyze-btn complyze-btn-primary" onclick="window.complyzeInterceptor.useOptimizedPrompt('${this.escapeHtml(optimizedPrompt).replace(/'/g, "\\'")}')">
            🔒 Use Secure Version
          </button>
          <button class="complyze-btn complyze-btn-secondary" onclick="window.complyzeInterceptor.editPromptManually('${this.escapeHtml(optimizedPrompt).replace(/'/g, "\\'")}')">
            ✏️ Edit Manually
          </button>
          <button class="complyze-btn complyze-btn-danger" onclick="window.complyzeInterceptor.sendOriginalPrompt()">
            ⚠️ Send Original (Risky)
          </button>
          <button class="complyze-btn complyze-btn-cancel" onclick="window.complyzeInterceptor.cancelSubmission()">
            ❌ Cancel
          </button>
        </div>

        <div style="margin-top: 16px; text-align: center; font-size: 12px; color: #6b7280;">
          Platform: ${this.currentPlatform} • ${new Date().toLocaleTimeString()}
        </div>
      </div>
    `;

    this.setupModalEventListeners(optimizedPrompt);
  }

  setupModalEventListeners(optimizedPrompt) {
    const modal = this.optimizationModal;
    
    modal.querySelector('.complyze-btn-primary')?.addEventListener('click', () => {
      this.useOptimizedPrompt(optimizedPrompt);
    });

    modal.querySelector('.complyze-btn-secondary')?.addEventListener('click', () => {
      this.editPromptManually(optimizedPrompt);
    });

    modal.querySelector('.complyze-btn-danger')?.addEventListener('click', () => {
      this.sendOriginalPrompt();
    });

    modal.querySelector('.complyze-btn-cancel')?.addEventListener('click', () => {
      this.cancelSubmission();
    });

    modal.addEventListener('click', (event) => {
      if (event.target === modal) {
        this.cancelSubmission();
      }
    });
  }

  useOptimizedPrompt(optimizedPrompt) {
    console.log('✅ User chose to use optimized prompt');
    
    this.setPromptText(optimizedPrompt);
    
    this.hideOptimizationModal();
    
    setTimeout(() => {
      this.submitWithCurrentText();
    }, 100);
  }

  editPromptManually(optimizedPrompt) {
    console.log('✏️ User chose to edit manually');
    
    this.setPromptText(optimizedPrompt);
    
    this.hideOptimizationModal();
    
    const input = document.querySelector(this.selectors.promptInput);
    if (input) {
      input.focus();
      if (input.setSelectionRange) {
        input.setSelectionRange(input.value.length, input.value.length);
      }
    }
  }

  sendOriginalPrompt() {
    console.log('⚠️ User chose to send original prompt (risky)');
    
    this.hideOptimizationModal();
    
    if (this.currentPromptData) {
      this.executeOriginalSubmit(
        this.currentPromptData.element, 
        this.currentPromptData.originalHandler
      );
    }
  }

  setPromptText(text) {
    const inputs = document.querySelectorAll(this.selectors.promptInput);
    
    for (const input of inputs) {
      if (input.tagName.toLowerCase() === 'textarea') {
        input.value = text;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
      } else if (input.contentEditable === 'true') {
        input.innerText = text;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
      }
    }
  }

  submitWithCurrentText() {
    const submitButton = document.querySelector(this.selectors.submitButton);
    if (submitButton) {
      this.enableSubmitButtons();
      
      this.isActive = false;
      
      setTimeout(() => {
        submitButton.click();
        setTimeout(() => {
          this.isActive = true;
        }, 1000);
      }, 100);
    }
  }

  executeOriginalSubmit(element, originalHandler) {
    if (!this.currentPromptData) return;
    
    this.enableSubmitButtons();
    
    this.isActive = false;
    
    setTimeout(() => {
      if (originalHandler) {
        originalHandler.call(element);
      } else if (element.tagName.toLowerCase() === 'form') {
        element.submit();
      } else {
        element.click();
      }
      
      setTimeout(() => {
        this.isActive = true;
      }, 1000);
    }, 100);
  }

  hideOptimizationModal() {
    if (this.optimizationModal) {
      this.optimizationModal.style.display = 'none';
    }
    this.resetModalState();
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  disableSubmitButtons() {
    const submitButtons = document.querySelectorAll(this.selectors.submitButton);
    
    submitButtons.forEach(button => {
      if (!button.dataset.complyzeOriginalDisabled) {
        button.dataset.complyzeOriginalDisabled = button.disabled || 'false';
        button.dataset.complyzeOriginalOpacity = button.style.opacity || '1';
        button.dataset.complyzeOriginalCursor = button.style.cursor || 'pointer';
        button.dataset.complyzeOriginalPointerEvents = button.style.pointerEvents || 'auto';
      }
      
      button.disabled = true;
      button.style.opacity = '0.5';
      button.style.cursor = 'not-allowed';
      button.style.pointerEvents = 'none';
      button.setAttribute('aria-disabled', 'true');
      
      if (!button.querySelector('.complyze-processing-indicator')) {
        const indicator = document.createElement('span');
        indicator.className = 'complyze-processing-indicator';
        indicator.innerHTML = ' 🔒';
        indicator.style.marginLeft = '4px';
        button.appendChild(indicator);
      }
    });
    
    console.log('🔒 Submit buttons disabled for security processing');
  }

  enableSubmitButtons() {
    const submitButtons = document.querySelectorAll(this.selectors.submitButton);
    
    submitButtons.forEach(button => {
      const originalDisabled = button.dataset.complyzeOriginalDisabled;
      const originalOpacity = button.dataset.complyzeOriginalOpacity;
      const originalCursor = button.dataset.complyzeOriginalCursor;
      const originalPointerEvents = button.dataset.complyzeOriginalPointerEvents;
      
      if (originalDisabled !== undefined) {
        button.disabled = originalDisabled === 'true';
        button.style.opacity = originalOpacity || '1';
        button.style.cursor = originalCursor || 'pointer';
        button.style.pointerEvents = originalPointerEvents || 'auto';
        button.removeAttribute('aria-disabled');
        
        delete button.dataset.complyzeOriginalDisabled;
        delete button.dataset.complyzeOriginalOpacity;
        delete button.dataset.complyzeOriginalCursor;
        delete button.dataset.complyzeOriginalPointerEvents;
      }
      
      const indicator = button.querySelector('.complyze-processing-indicator');
      if (indicator) {
        indicator.remove();
      }
    });
    
    console.log('✅ Submit buttons re-enabled');
  }

  createOptimizationModal() {
    const existingModal = document.getElementById('complyze-optimization-modal');
    if (existingModal) {
      existingModal.remove();
    }

    // Inject shared styles
    this.injectModalStyles();

    const modal = document.createElement('div');
    modal.id = 'complyze-optimization-modal';
    modal.className = 'complyze-modal';
    
    document.body.appendChild(modal);
    this.optimizationModal = modal;
    return modal;
  }

  injectModalStyles() {
    if (!document.querySelector('#complyze-modal-styles')) {
      const style = document.createElement('style');
      style.id = 'complyze-modal-styles';
      style.textContent = `
        .complyze-modal {
          display: none;
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(0, 0, 0, 0.8);
          z-index: 999999;
          justify-content: center;
          align-items: center;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }

        .complyze-modal-content {
          background: white;
          border-radius: 12px;
          max-width: 800px;
          max-height: 90vh;
          overflow-y: auto;
          padding: 24px;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
          position: relative;
          margin: 20px;
        }

        .complyze-modal-content.loading {
          text-align: center;
          max-width: 400px;
        }

        .complyze-modal-header h3 {
          color: #1f2937;
          margin: 0 0 8px 0;
          font-size: 20px;
          font-weight: 600;
        }

        .complyze-modal-header p {
          color: #6b7280;
          margin: 0 0 20px 0;
        }

        .complyze-prompt-comparison {
          margin: 20px 0;
        }

        .complyze-prompt-section {
          margin-bottom: 20px;
        }

        .complyze-prompt-section h4 {
          margin: 0 0 8px 0;
          font-size: 14px;
          font-weight: 600;
        }

        .complyze-prompt-box {
          border: 2px solid #e5e7eb;
          border-radius: 8px;
          padding: 12px;
          background: #f9fafb;
          max-height: 150px;
          overflow-y: auto;
        }

        .complyze-prompt-box.original {
          border-color: #fca5a5;
          background: #fef2f2;
        }

        .complyze-prompt-box.optimized {
          border-color: #86efac;
          background: #f0fdf4;
        }

        .complyze-prompt-box pre {
          margin: 0;
          white-space: pre-wrap;
          word-wrap: break-word;
          font-size: 13px;
          line-height: 1.4;
          color: #374151;
        }

        .complyze-improvements {
          background: #eff6ff;
          border: 1px solid #bfdbfe;
          border-radius: 8px;
          padding: 16px;
          margin: 20px 0;
        }

        .complyze-improvements h4 {
          margin: 0 0 12px 0;
          color: #1e40af;
          font-size: 14px;
        }

        .complyze-improvements ul {
          margin: 0;
          padding-left: 20px;
        }

        .complyze-improvements li {
          color: #1e40af;
          margin-bottom: 4px;
          font-size: 13px;
        }

        .complyze-modal-actions {
          display: flex;
          gap: 12px;
          flex-wrap: wrap;
          margin-top: 24px;
        }

        .complyze-btn {
          padding: 10px 16px;
          border: none;
          border-radius: 6px;
          font-size: 14px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s;
          flex: 1;
          min-width: 120px;
        }

        .complyze-btn-primary {
          background: #059669;
          color: white;
        }

        .complyze-btn-primary:hover {
          background: #047857;
        }

        .complyze-btn-secondary {
          background: #3b82f6;
          color: white;
        }

        .complyze-btn-secondary:hover {
          background: #2563eb;
        }

        .complyze-btn-danger {
          background: #dc2626;
          color: white;
        }

        .complyze-btn-danger:hover {
          background: #b91c1c;
        }

        .complyze-btn-cancel {
          background: #6b7280;
          color: white;
        }

        .complyze-btn-cancel:hover {
          background: #4b5563;
        }

        .complyze-loading-spinner {
          width: 40px;
          height: 40px;
          border: 4px solid #e5e7eb;
          border-top: 4px solid #059669;
          border-radius: 50%;
          animation: complyze-spin 1s linear infinite;
          margin: 0 auto 20px;
        }

        .complyze-progress-bar {
          width: 100%;
          height: 8px;
          background: #e5e7eb;
          border-radius: 4px;
          overflow: hidden;
          margin: 16px 0;
        }

        .complyze-progress-fill {
          height: 100%;
          background: #059669;
          border-radius: 4px;
          animation: complyze-progress 3s ease-in-out;
        }

        .complyze-loading-text {
          color: #6b7280;
          font-size: 14px;
          margin: 16px 0 0 0;
        }

        .complyze-submit-disabled-notice {
          background: #fef3c7;
          border: 1px solid #f59e0b;
          border-radius: 6px;
          padding: 12px;
          margin: 16px 0 0 0;
        }

        .complyze-submit-disabled-notice p {
          margin: 0;
          font-size: 13px;
          color: #92400e;
          font-weight: 500;
          text-align: center;
        }

        .complyze-minimize-btn {
          position: absolute;
          top: 16px;
          right: 16px;
          background: #dc2626;
          color: white;
          border: none;
          border-radius: 8px;
          padding: 12px 16px;
          font-size: 14px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          gap: 6px;
          z-index: 1000;
          box-shadow: 0 2px 8px rgba(220, 38, 38, 0.3);
        }

        .complyze-minimize-btn:hover {
          background: #b91c1c;
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(220, 38, 38, 0.4);
        }

        .complyze-minimize-btn .minimize-icon {
          font-size: 18px;
          font-weight: bold;
          line-height: 1;
        }

        .complyze-minimize-btn .minimize-text {
          font-size: 13px;
        }

        @keyframes complyze-spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }

        @keyframes complyze-progress {
          0% { width: 0%; }
          50% { width: 70%; }
          100% { width: 100%; }
        }

        @media (max-width: 640px) {
          .complyze-modal-content {
            margin: 10px;
            padding: 16px;
          }
          
          .complyze-modal-actions {
            flex-direction: column;
          }
          
          .complyze-minimize-btn {
            padding: 10px 12px;
            font-size: 12px;
          }
          
          .complyze-minimize-btn .minimize-text {
            display: none;
          }
        }
      `;
      document.head.appendChild(style);
    }
  }

  setupMessageListeners() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.type === 'optimization_complete') {
        this.showOptimizationModal(message.result);
        sendResponse({ success: true });
      }
      return true;
    });
  }

  quickDismiss() {
    console.log('⚡ Quick dismiss triggered');
    this.cancelSubmission();
  }

  cancelSubmission() {
    console.log('❌ User cancelled submission');
    this.hideOptimizationModal();
    this.resetModalState();
  }

  resetModalState() {
    this.isModalVisible = false;
    this.isProcessing = false;
    this.enableSubmitButtons();
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.complyzeInterceptor = new ComplyzePromptInterceptor();
  });
} else {
  window.complyzeInterceptor = new ComplyzePromptInterceptor();
}

// Ensure global access with delay for dynamic content
setTimeout(() => {
  if (!window.complyzeInterceptor) {
    window.complyzeInterceptor = new ComplyzePromptInterceptor();
  }
}, 1000); 
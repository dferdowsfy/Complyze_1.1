// Debug script to test Complyze auth endpoints
console.log('Complyze Debug: Testing auth endpoints...');

async function testAuthEndpoints() {
    const endpoints = [
        'https://complyze.co/api/auth/login',
        'https://complyze.co/api/auth/signin', 
        'https://complyze.co/api/auth/check'
    ];
    
    for (const endpoint of endpoints) {
        console.log(`Testing endpoint: ${endpoint}`);
        
        try {
            // Test basic connectivity first
            const testResponse = await fetch(endpoint, {
                method: 'OPTIONS'
            });
            console.log(`OPTIONS ${endpoint}:`, testResponse.status, testResponse.statusText);
            console.log('Headers:', [...testResponse.headers.entries()]);
        } catch (error) {
            console.error(`OPTIONS ${endpoint} failed:`, error);
        }
        
        try {
            // Test actual POST
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'Origin': 'https://complyze.co'
                },
                credentials: 'include',
                body: JSON.stringify({ 
                    email: 'test@example.com',
                    password: 'testpass'
                })
            });
            
            console.log(`POST ${endpoint}:`, response.status, response.statusText);
            console.log('Response headers:', [...response.headers.entries()]);
            
            const responseText = await response.text();
            console.log('Response body:', responseText);
            
        } catch (error) {
            console.error(`POST ${endpoint} failed:`, error);
            console.error('Error details:', {
                name: error.name,
                message: error.message,
                stack: error.stack
            });
        }
        
        console.log('---');
    }
}

// Test when page loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', testAuthEndpoints);
} else {
    testAuthEndpoints();
}

// Also make it available globally for manual testing
window.testComplyzeAuth = testAuthEndpoints; 
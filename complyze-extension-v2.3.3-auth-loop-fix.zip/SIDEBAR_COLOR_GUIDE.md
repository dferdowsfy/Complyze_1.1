# 🎨 Sidebar Background Color Customization Guide

## Quick Changes

The main sidebar background color is controlled by **line 408** in `floating-ui.js`:

```javascript
background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%); /* 👈 CHANGE THIS LINE - Current Complyze Light Theme */
```

## Popular Color Options

### 1. Current Complyze Light Theme (Default)
```javascript
background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
```

### 2. Original Dark Blue Theme
```javascript
background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
```

### 3. Dark Purple Theme
```javascript
background: linear-gradient(135deg, #4c1d95 0%, #312e81 100%);
```

### 4. Dark Green Theme
```javascript
background: linear-gradient(135deg, #134e4a 0%, #064e3b 100%);
```

### 5. Dark Red Theme
```javascript
background: linear-gradient(135deg, #7f1d1d 0%, #450a0a 100%);
```

### 6. Charcoal Black Theme
```javascript
background: linear-gradient(135deg, #374151 0%, #111827 100%);
```

### 7. Solid Colors (No Gradient)
```javascript
background: #ffffff; /* Solid white */
background: #f8fafc; /* Solid light gray */
background: #1e293b; /* Solid dark blue */
background: #18181b; /* Solid dark gray */
```

### 8. Glassmorphism Effect (Light)
```javascript
background: rgba(255, 255, 255, 0.8);
backdrop-filter: blur(20px);
```

### 9. Glassmorphism Effect (Dark)
```javascript
background: rgba(30, 41, 59, 0.9);
backdrop-filter: blur(20px);
```

## Other Customizable Areas

### Header Section Background (line 415)
```javascript
background: rgba(255, 255, 255, 0.02); /* Very subtle white overlay */
```

### Buttons Section Background (line 441)
```javascript
background: rgba(255, 255, 255, 0.02); /* Bottom buttons area */
```

### Warning Box (line 423)
```javascript
background: rgba(239, 68, 68, 0.1); /* Red warning box */
```

### Success Box (line 433)
```javascript
background: rgba(16, 185, 129, 0.1); /* Green success box */
```

## How to Apply Changes

1. Open `complyze-extension-v2/floating-ui.js`
2. Go to line 408 (the main sidebar background line marked with 👈)
3. Replace the `background:` value with your desired color
4. Save the file
5. Reload the Chrome extension
6. Test on ChatGPT/Claude to see the changes

## Pro Tips

- Use `rgba()` values for transparency effects
- Gradients create more professional looks: `linear-gradient(direction, color1, color2)`
- Keep contrast high for text readability
- Test colors in both light and dark environments 
// Test script for validating the subtle alerts system
console.log("🧪 Complyze Subtle Alerts Test Script");

class SubtleAlertsTest {
    constructor() {
        this.tests = [];
        this.results = [];
    }

    // Simulate typing sensitive content to trigger alerts
    async testSensitiveDataDetection() {
        console.log("📋 Testing sensitive data detection...");
        
        const testCases = [
            {
                name: "Social Security Number",
                content: "My SSN is 123-45-6789",
                expectedRisk: "high"
            },
            {
                name: "Credit Card Number", 
                content: "My credit card is 4532-1234-5678-9012",
                expectedRisk: "high"
            },
            {
                name: "Email Address",
                content: "Contact me at john.doe@example.com",
                expectedRisk: "medium"
            },
            {
                name: "Phone Number",
                content: "Call me at (555) 123-4567",
                expectedRisk: "medium"
            }
        ];

        for (const testCase of testCases) {
            await this.simulateInput(testCase);
        }
    }

    async simulateInput(testCase) {
        console.log(`🔍 Testing: ${testCase.name}`);
        
        // Find input element (simulate ChatGPT/Claude input)
        const inputElement = this.createTestInput();
        
        // Simulate typing
        inputElement.value = testCase.content;
        inputElement.dispatchEvent(new Event('input', { bubbles: true }));
        
        // Wait for analysis
        await this.waitForAnalysis();
        
        // Check if alert appeared
        const alertElement = this.checkForAlert();
        
        this.results.push({
            test: testCase.name,
            content: testCase.content,
            expected: testCase.expectedRisk,
            alertShown: !!alertElement,
            alertType: this.getAlertType(alertElement),
            passed: !!alertElement
        });
        
        // Clean up
        if (alertElement) {
            alertElement.remove();
        }
        inputElement.remove();
    }

    createTestInput() {
        const input = document.createElement('textarea');
        input.id = 'test-prompt-input';
        input.placeholder = "Test message...";
        input.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 500px;
            height: 100px;
            padding: 12px;
            border: 2px solid #ccc;
            border-radius: 8px;
            font-size: 14px;
            font-family: system-ui;
            z-index: 999999;
            background: white;
        `;
        document.body.appendChild(input);
        input.focus();
        return input;
    }

    async waitForAnalysis() {
        // Wait for potential analysis processing
        return new Promise(resolve => setTimeout(resolve, 1500));
    }

    checkForAlert() {
        // Check for warning alert
        const warning = document.querySelector('#complyze-realtime-warning');
        if (warning) return warning;
        
        // Check for info alert
        const info = document.querySelector('#complyze-realtime-info');
        if (info) return info;
        
        // Check for modal
        const modal = document.querySelector('#complyze-safe-prompt-modal');
        if (modal) return modal;
        
        return null;
    }

    getAlertType(alertElement) {
        if (!alertElement) return 'none';
        
        if (alertElement.id === 'complyze-realtime-warning') return 'warning';
        if (alertElement.id === 'complyze-realtime-info') return 'info';
        if (alertElement.id === 'complyze-safe-prompt-modal') return 'modal';
        
        return 'unknown';
    }

    // Test visual appearance of alerts
    testAlertStyling() {
        console.log("🎨 Testing alert styling...");
        
        const tests = [
            {
                name: "Backdrop Filter Support",
                test: () => CSS.supports('backdrop-filter', 'blur(10px)') || CSS.supports('-webkit-backdrop-filter', 'blur(10px)')
            },
            {
                name: "RGBA Background Support",
                test: () => CSS.supports('background', 'rgba(0, 0, 0, 0.5)')
            },
            {
                name: "Transform Support",
                test: () => CSS.supports('transform', 'translateY(-20px) scale(0.95)')
            },
            {
                name: "Animation Support",
                test: () => CSS.supports('animation', 'slideDown 0.3s ease-out')
            }
        ];

        tests.forEach(test => {
            const result = test.test();
            console.log(`${result ? '✅' : '❌'} ${test.name}: ${result ? 'Supported' : 'Not supported'}`);
            
            this.results.push({
                test: test.name,
                type: 'styling',
                passed: result
            });
        });
    }

    // Test animation performance
    async testAnimationPerformance() {
        console.log("⚡ Testing animation performance...");
        
        const testElement = document.createElement('div');
        testElement.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            width: 300px;
            height: 100px;
            background: rgba(220, 38, 38, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            transform: translateY(-25px) scale(0.95);
            opacity: 0;
            filter: blur(5px);
            animation: slideDownSubtle 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
            z-index: 999999;
        `;
        
        // Add animation keyframes
        if (!document.querySelector('#test-animation-styles')) {
            const style = document.createElement('style');
            style.id = 'test-animation-styles';
            style.textContent = `
                @keyframes slideDownSubtle {
                    0% { 
                        transform: translateY(-25px) scale(0.95); 
                        opacity: 0; 
                        filter: blur(5px);
                    }
                    100% { 
                        transform: translateY(0) scale(1); 
                        opacity: 1; 
                        filter: blur(0px);
                    }
                }
            `;
            document.head.appendChild(style);
        }
        
        document.body.appendChild(testElement);
        
        // Measure animation performance
        const startTime = performance.now();
        
        await new Promise(resolve => {
            testElement.addEventListener('animationend', () => {
                const endTime = performance.now();
                const duration = endTime - startTime;
                
                console.log(`🏁 Animation completed in ${duration.toFixed(2)}ms`);
                
                this.results.push({
                    test: 'Animation Performance',
                    type: 'performance',
                    duration: duration,
                    passed: duration < 500 // Should complete in under 500ms
                });
                
                testElement.remove();
                resolve();
            });
        });
    }

    // Test modal interaction
    async testModalInteraction() {
        console.log("🖱️ Testing modal interaction...");
        
        // Create mock analysis data
        const mockAnalysis = {
            risk_level: 'high',
            detectedPII: ['SSN', 'CREDIT_CARD'],
            optimized_prompt: 'This is a safe version of your prompt with sensitive data removed.'
        };
        
        // Create test input
        const testInput = this.createTestInput();
        testInput.value = "My SSN is 123-45-6789";
        
        // Simulate creating safe prompt panel
        this.simulateCreateSafePromptPanel(testInput, mockAnalysis);
        
        // Test interactions
        await this.testModalCloseInteractions();
        
        testInput.remove();
    }

    simulateCreateSafePromptPanel(promptElement, analysis) {
        // Simplified version of createSafePromptPanel for testing
        const modal = document.createElement('div');
        modal.id = 'complyze-safe-prompt-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(8px);
            z-index: 2147483647;
            display: flex;
            align-items: center;
            justify-content: center;
        `;
        
        const panel = document.createElement('div');
        panel.innerHTML = `
            <button id="complyze-close-panel">×</button>
            <div>Test Modal Content</div>
            <button id="complyze-cancel">Cancel</button>
        `;
        panel.style.cssText = `
            background: rgba(255, 255, 255, 0.98);
            padding: 20px;
            border-radius: 16px;
            backdrop-filter: blur(20px);
        `;
        
        modal.appendChild(panel);
        document.body.appendChild(modal);
    }

    async testModalCloseInteractions() {
        const modal = document.querySelector('#complyze-safe-prompt-modal');
        if (!modal) {
            console.error('❌ Modal not found for interaction testing');
            return;
        }
        
        console.log("🔄 Testing modal close interactions...");
        
        // Test close button
        const closeButton = modal.querySelector('#complyze-close-panel');
        if (closeButton) {
            closeButton.click();
            await this.wait(100);
            
            if (!document.querySelector('#complyze-safe-prompt-modal')) {
                console.log("✅ Close button working");
                this.results.push({ test: 'Modal Close Button', passed: true });
            } else {
                console.log("❌ Close button not working");
                this.results.push({ test: 'Modal Close Button', passed: false });
            }
        }
    }

    async wait(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // Run all tests
    async runAllTests() {
        console.log("🚀 Starting Complyze Subtle Alerts Test Suite");
        
        this.testAlertStyling();
        await this.testAnimationPerformance();
        await this.testModalInteraction();
        await this.testSensitiveDataDetection();
        
        this.generateReport();
    }

    generateReport() {
        console.log("\n📊 TEST REPORT");
        console.log("=" .repeat(50));
        
        const passed = this.results.filter(r => r.passed).length;
        const total = this.results.length;
        
        console.log(`Overall: ${passed}/${total} tests passed (${((passed/total)*100).toFixed(1)}%)`);
        console.log("");
        
        this.results.forEach(result => {
            const icon = result.passed ? '✅' : '❌';
            console.log(`${icon} ${result.test}`);
            
            if (result.duration) {
                console.log(`   Duration: ${result.duration.toFixed(2)}ms`);
            }
            if (result.alertType) {
                console.log(`   Alert Type: ${result.alertType}`);
            }
        });
        
        console.log("\n🎯 Recommendations:");
        
        if (this.results.some(r => r.test.includes('Backdrop Filter') && !r.passed)) {
            console.log("⚠️  Backdrop filter not supported - effects will degrade gracefully");
        }
        
        if (this.results.some(r => r.type === 'performance' && r.duration > 300)) {
            console.log("⚠️  Animation performance could be improved");
        }
        
        const alertTests = this.results.filter(r => r.alertShown !== undefined);
        if (alertTests.length === 0) {
            console.log("⚠️  No alerts were triggered - check if PromptWatcher is active");
        }
        
        console.log("✅ Test suite completed!");
    }
}

// Auto-run tests when script is loaded
if (typeof window !== 'undefined') {
    window.SubtleAlertsTest = SubtleAlertsTest;
    
    // Add test button to page
    const testButton = document.createElement('button');
    testButton.textContent = '🧪 Run Subtle Alerts Tests';
    testButton.style.cssText = `
        position: fixed;
        top: 20px;
        left: 20px;
        padding: 10px 15px;
        background: #3b82f6;
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        z-index: 999999;
        font-size: 14px;
        font-weight: 600;
    `;
    
    testButton.addEventListener('click', async () => {
        const tester = new SubtleAlertsTest();
        await tester.runAllTests();
    });
    
    document.body.appendChild(testButton);
    
    console.log("🧪 Subtle Alerts Test Suite loaded. Click the button to run tests.");
}

// Export for use in other contexts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SubtleAlertsTest;
} 
# 🛡️ Complyze Prompt Interceptor - Real-time Blocking & Optimization

## Overview

The new **Prompt Interceptor** adds real-time blocking functionality to the Complyze Chrome extension. When users attempt to submit prompts containing sensitive information, the system:

1. **Immediately blocks** the submission
2. **Shows a loading modal** while AI processes the prompt
3. **Displays an optimization modal** with secure alternatives
4. **Gives users choices** for how to proceed

## 🚀 Key Features

### Real-time Detection & Blocking
- Intercepts form submissions and button clicks on AI platforms
- Analyzes prompts for sensitive data (PII, credentials, etc.) 
- Prevents submission until user makes a security choice
- Works across ChatGPT, Claude, Gemini, and other platforms

### AI-Powered Optimization Modal
- Beautiful, professional UI with side-by-side comparison
- Shows original prompt vs. secure optimized version
- Lists specific security improvements made
- Multiple action options for users

### Smart Triggering
- Only triggers on meaningful content (4+ words)
- Detects sensitive patterns: emails, SSNs, credit cards, API keys
- Also triggers on prompt-like content with security implications
- Minimal false positives

## 🎯 User Experience Flow

### 1. User Types Sensitive Prompt
```
User: "Help me debug this API call with key sk-1234567890abcdef..."
```

### 2. System Intercepts Submission
- Form submission blocked immediately
- Loading modal appears: "🔒 Securing Your Prompt"
- AI processes prompt in background (1-3 seconds)

### 3. Optimization Modal Appears
Shows:
- **Original prompt** (highlighted as containing sensitive data)
- **Optimized prompt** (secure version)
- **List of improvements** made
- **Action buttons**: Use Secure Version, Edit Manually, Send Original, Cancel

### 4. User Chooses Action
- **🚀 Use Secure Version**: Replaces prompt and submits safely
- **✏️ Edit Manually**: Sets optimized prompt for user editing
- **⚠️ Send Original**: Allows risky submission (not recommended)
- **❌ Cancel**: Cancels submission entirely

## 🔧 Technical Implementation

### Files Added/Modified

#### New Files:
- `prompt-interceptor.js` - Main interceptor class with modal
- `test-interceptor.html` - Test page for verification

#### Modified Files:
- `manifest.json` - Added new script to content scripts
- `background.js` - Updated message handling for optimization

### Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│  Content Script │    │  Background      │    │   OpenRouter    │
│  (Interceptor)  │◄──►│  Script          │◄──►│   AI Service    │
│                 │    │  (Optimization)  │    │   (Gemini)      │
└─────────────────┘    └──────────────────┘    └─────────────────┘
         ▲
         │
         ▼
┌─────────────────┐
│ Optimization    │
│ Modal UI        │
│ (User Choice)   │
└─────────────────┘
```

### Platform Support

Configured with platform-specific selectors for:
- **ChatGPT**: `textarea[data-id]`, `button[data-testid="send-button"]`
- **Claude**: `div[contenteditable="true"]`, `button[aria-label="Send Message"]`
- **Gemini**: `textarea[data-testid="chat-input"]`, `button[data-testid="send-button"]`
- **Poe**: `textarea[placeholder*="Send a message"]`
- **Character.AI**: `textarea[placeholder*="Type a message"]`

## 🧪 Testing

### Test Page
Open `test-interceptor.html` in browser with extension installed:
- Contains safe and sensitive example prompts
- Real-time testing interface
- Console logging for debugging

### Manual Testing Steps

1. **Install Extension**
   ```bash
   1. Go to chrome://extensions/
   2. Enable Developer mode
   3. Click "Load unpacked"
   4. Select complyze-extension-v2 folder
   ```

2. **Test on Real Platforms**
   - Visit ChatGPT, Claude, or Gemini
   - Try typing prompts with emails, SSNs, API keys
   - Verify modal appears and blocking works

3. **Test with Test Page**
   - Open `test-interceptor.html`
   - Click example prompts to test different scenarios
   - Check console for detailed logs

### Example Test Cases

**✅ Safe Prompts (Should Submit Normally):**
- "Explain machine learning algorithms"
- "Help me write a professional email template"

**⚠️ Sensitive Prompts (Should Trigger Modal):**
- "Email john.doe@company.com about the project"
- "Debug API call with key sk-1234567890abcdef..."
- "Process customer data: SSN 123-45-6789"
- "Call customer at 555-123-4567"

## 🔒 Security Features

### Sensitive Data Detection
- **Emails**: `user@domain.com`
- **SSNs**: `123-45-6789`, `123456789`
- **Phone Numbers**: `555-123-4567`, `(555) 123-4567`
- **Credit Cards**: `4532-1234-5678-9012`
- **API Keys**: `sk-`, `sk-or-v1-`, `sk-ant-`, etc.
- **IP Addresses**: `192.168.1.1`

### AI Optimization
- Uses Google Gemini 2.5 Pro via OpenRouter
- Removes sensitive data while preserving intent
- Provides natural language replacements
- Lists specific improvements made

### Data Handling
- **No storage** of original sensitive prompts
- Optimized prompts processed securely
- All telemetry sent to production `https://complyze.co/api`

## 🚨 User Rules Applied

✅ **Immediate Blocking**: Submissions blocked instantly when sensitive data detected  
✅ **Consistent Branding**: Uses Complyze favicon/icons  
✅ **Production API**: All data sent to `https://complyze.co/api`  
✅ **OpenRouter Production**: Uses `https://openrouter.ai/api/v1`  
✅ **AI-First Optimization**: Primary optimization via Google Gemini with natural rephrasing  

## 📈 Analytics & Telemetry

All prompt events are tracked and sent to:
- **Endpoint**: `https://complyze.co/api/prompts/ingest`
- **Data**: Anonymized analysis results, platform info, user choices
- **Purpose**: Security monitoring, optimization improvement, compliance reporting

## 🔄 Next Steps

After installation and testing:

1. **User Training**: Educate users on the new blocking feature
2. **Monitor Analytics**: Track blocking frequency and user choices  
3. **Refinement**: Adjust sensitivity based on user feedback
4. **Additional Platforms**: Add support for more AI platforms
5. **Enterprise Features**: Custom policies, approval workflows

## 📞 Support

If the interceptor isn't working:

1. Check browser console for errors
2. Verify extension is enabled in chrome://extensions/
3. Test with `test-interceptor.html` page
4. Reload extension and try again
5. Check that background script loads without errors

---

**The Complyze Prompt Interceptor provides enterprise-grade security for AI interactions while maintaining a smooth user experience.** 
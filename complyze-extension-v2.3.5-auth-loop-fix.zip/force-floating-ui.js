// Force create floating UI for debugging
console.log("🔧 Force Floating UI Debug Script");

// Check current state
console.log("URL:", window.location.href);
console.log("ComplyzeFloatingUI class:", typeof window.ComplyzeFloatingUI);
console.log("complyzeFloatingUI instance:", typeof window.complyzeFloatingUI);

// Check if we're on a supported platform
const hostname = window.location.hostname;
const supportedDomains = [
    'chat.openai.com',
    'chatgpt.com', 
    'claude.ai',
    'gemini.google.com'
];

const isSupported = supportedDomains.some(domain => hostname.includes(domain));
console.log("Supported platform:", isSupported, "Hostname:", hostname);

// Force create if needed
if (isSupported) {
    // Remove existing elements
    const existingIcon = document.querySelector('#complyze-floating-icon');
    const existingSidebar = document.querySelector('#complyze-sidebar');
    
    if (existingIcon) {
        console.log("Removing existing icon");
        existingIcon.remove();
    }
    if (existingSidebar) {
        console.log("Removing existing sidebar");
        existingSidebar.remove();
    }
    
    // Force create new instance
    if (window.ComplyzeFloatingUI) {
        console.log("Creating new floating UI instance");
        window.complyzeFloatingUI = new window.ComplyzeFloatingUI();
    } else {
        console.error("ComplyzeFloatingUI class not found!");
    }
    
    // Check if icon was created
    setTimeout(() => {
        const icon = document.querySelector('#complyze-floating-icon');
        const sidebar = document.querySelector('#complyze-sidebar');
        console.log("Icon created:", !!icon);
        console.log("Sidebar created:", !!sidebar);
        
        if (icon) {
            console.log("Icon position:", icon.style.position, icon.style.top, icon.style.right);
        }
    }, 1000);
} else {
    console.log("Not on supported platform, skipping UI creation");
}

// Manual creation function
window.forceCreateFloatingIcon = function() {
    console.log("🚀 Manually creating floating icon...");
    
    // Remove existing
    const existing = document.querySelector('#complyze-floating-icon');
    if (existing) existing.remove();
    
    // Create icon
    const icon = document.createElement('div');
    icon.id = 'complyze-floating-icon';
    icon.innerHTML = '<div style="width: 24px; height: 24px; background: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; color: #0E1E36;">C</div>';
    icon.style.cssText = `
        position: fixed !important;
        top: 40% !important;
        right: 30px !important;
        width: 50px !important;
        height: 50px !important;
        background: #0E1E36 !important;
        border: 2px solid rgba(255, 255, 255, 0.3) !important;
        border-radius: 50% !important;
        cursor: pointer !important;
        z-index: 999999 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3) !important;
    `;
    
    icon.addEventListener('click', () => {
        alert('Floating icon clicked! Extension is working.');
    });
    
    document.body.appendChild(icon);
    console.log("✅ Manual floating icon created");
};

console.log("💡 Run forceCreateFloatingIcon() to manually create the icon"); 
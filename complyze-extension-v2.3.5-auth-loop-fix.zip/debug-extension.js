// Complyze Extension Debug & Diagnostics
console.log('🔧 Complyze Extension Debug Script Starting...');

// Test 1: Check Chrome Extension APIs
function testChromeAPIs() {
  console.log('\n=== 🔍 Testing Chrome Extension APIs ===');
  
  if (typeof chrome === 'undefined') {
    console.error('❌ Chrome object not available');
    return false;
  }
  console.log('✅ Chrome object available');
  
  if (!chrome.runtime) {
    console.error('❌ Chrome runtime not available');
    return false;
  }
  console.log('✅ Chrome runtime available');
  console.log('📍 Extension ID:', chrome.runtime.id);
  
  if (!chrome.storage) {
    console.error('❌ Chrome storage not available');
    return false;
  }
  console.log('✅ Chrome storage available');
  
  if (!chrome.tabs) {
    console.error('❌ Chrome tabs not available');
    return false;
  }
  console.log('✅ Chrome tabs available');
  
  return true;
}

// Test 2: Check Background Script Communication
async function testBackgroundScript() {
  console.log('\n=== 📡 Testing Background Script Communication ===');
  
  try {
    const response = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'debug_test' }, (response) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(response);
        }
      });
    });
    
    console.log('✅ Background script responded:', response);
    return true;
  } catch (error) {
    console.error('❌ Background script communication failed:', error.message);
    return false;
  }
}

// Test 3: Check Storage
async function testStorage() {
  console.log('\n=== 💾 Testing Storage ===');
  
  try {
    // Test write
    await chrome.storage.local.set({ debug_test: 'test_value' });
    console.log('✅ Storage write successful');
    
    // Test read
    const result = await chrome.storage.local.get(['debug_test']);
    if (result.debug_test === 'test_value') {
      console.log('✅ Storage read successful');
    } else {
      console.error('❌ Storage read failed');
      return false;
    }
    
    // Clean up
    await chrome.storage.local.remove(['debug_test']);
    console.log('✅ Storage cleanup successful');
    
    return true;
  } catch (error) {
    console.error('❌ Storage test failed:', error.message);
    return false;
  }
}

// Test 4: Check Current Tab and Content Script
async function testContentScript() {
  console.log('\n=== 📄 Testing Content Script Injection ===');
  
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs.length === 0) {
      console.error('❌ No active tab found');
      return false;
    }
    
    const tab = tabs[0];
    console.log('📍 Current tab:', tab.url);
    
    // Check if we can inject scripts
    if (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
      console.log('⚠️ Cannot inject into chrome:// pages (this is normal)');
      return true;
    }
    
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          return {
            url: window.location.href,
            hasComplyze: !!window.complyzeContentScript,
            timestamp: new Date().toISOString()
          };
        }
      });
      
      console.log('✅ Content script injection successful:', results[0].result);
      return true;
    } catch (injectionError) {
      console.error('❌ Content script injection failed:', injectionError.message);
      return false;
    }
  } catch (error) {
    console.error('❌ Content script test failed:', error.message);
    return false;
  }
}

// Test 5: Check Authentication Status
async function testAuthentication() {
  console.log('\n=== 🔐 Testing Authentication Status ===');
  
  try {
    const stored = await chrome.storage.local.get(['accessToken', 'user']);
    
    if (stored.accessToken) {
      console.log('✅ Access token found');
      console.log('👤 User:', stored.user?.email || 'Unknown');
    } else {
      console.log('⚠️ No access token found - extension requires authentication');
    }
    
    // Test authentication check with background script
    try {
      const authResponse = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ type: 'check_auth' }, (response) => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            resolve(response);
          }
        });
      });
      
      console.log('✅ Auth check response:', authResponse);
    } catch (authError) {
      console.error('❌ Auth check failed:', authError.message);
    }
    
    return true;
  } catch (error) {
    console.error('❌ Authentication test failed:', error.message);
    return false;
  }
}

// Test 6: Check Network Connectivity
async function testNetworkConnectivity() {
  console.log('\n=== 🌐 Testing Network Connectivity ===');
  
  try {
    const response = await fetch('https://complyze.co/api/health', { 
      method: 'GET',
      mode: 'cors'
    });
    
    if (response.ok) {
      console.log('✅ Network connectivity to Complyze API successful');
      return true;
    } else {
      console.error('❌ Network connectivity failed:', response.status, response.statusText);
      return false;
    }
  } catch (error) {
    console.error('❌ Network test failed:', error.message);
    return false;
  }
}

// Main Debug Function
async function runAllTests() {
  console.log('🚀 Starting Complyze Extension Diagnostics...\n');
  
  const results = {
    chromeAPIs: false,
    backgroundScript: false,
    storage: false,
    contentScript: false,
    authentication: false,
    network: false
  };
  
  // Run all tests
  results.chromeAPIs = testChromeAPIs();
  results.backgroundScript = await testBackgroundScript();
  results.storage = await testStorage();
  results.contentScript = await testContentScript();
  results.authentication = await testAuthentication();
  results.network = await testNetworkConnectivity();
  
  // Summary
  console.log('\n=== 📊 DIAGNOSTIC SUMMARY ===');
  console.log('Chrome APIs:', results.chromeAPIs ? '✅' : '❌');
  console.log('Background Script:', results.backgroundScript ? '✅' : '❌');
  console.log('Storage:', results.storage ? '✅' : '❌');
  console.log('Content Script:', results.contentScript ? '✅' : '❌');
  console.log('Authentication:', results.authentication ? '✅' : '❌');
  console.log('Network:', results.network ? '✅' : '❌');
  
  const failedTests = Object.entries(results).filter(([_, passed]) => !passed);
  
  if (failedTests.length === 0) {
    console.log('\n🎉 All tests passed! Extension should be working.');
  } else {
    console.log('\n⚠️ Failed tests:', failedTests.map(([test]) => test).join(', '));
    console.log('\n🔧 RECOMMENDED ACTIONS:');
    
    if (!results.chromeAPIs) {
      console.log('• Reload the extension in chrome://extensions/');
    }
    if (!results.backgroundScript) {
      console.log('• Check background script console for errors');
      console.log('• Try disabling and re-enabling the extension');
    }
    if (!results.authentication) {
      console.log('• Click the extension icon to authenticate');
      console.log('• Visit https://complyze.co/dashboard to log in');
    }
    if (!results.network) {
      console.log('• Check internet connection');
      console.log('• Try disabling ad blockers or VPN');
    }
  }
  
  return results;
}

// Auto-run if in extension context
if (typeof chrome !== 'undefined' && chrome.runtime) {
  runAllTests().catch(console.error);
} else {
  console.log('⚠️ Not running in extension context - run manually with runAllTests()');
}

// Export for manual use
window.complyzeDebug = { runAllTests, testChromeAPIs, testBackgroundScript, testStorage, testContentScript, testAuthentication, testNetworkConnectivity }; 
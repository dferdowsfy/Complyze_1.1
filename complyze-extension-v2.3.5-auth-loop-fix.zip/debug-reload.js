// Debug script for checking extension status
console.log("🔍 Complyze Extension Debug Check");
console.log("Extension ID:", chrome.runtime.id);
console.log("Extension Version:", chrome.runtime.getManifest().version);
console.log("Current URL:", window.location.href);
console.log("Supported Platform:", document.querySelector('#complyze-floating-icon') ? 'YES - UI Found' : 'NO - UI Missing');

// Check if scripts are loaded
const scripts = [
    'content.js',
    'floating-ui.js', 
    'prompt-interceptor.js'
];

scripts.forEach(script => {
    console.log(`Script ${script}:`, window[script] ? 'Loaded' : 'Not detected');
});

// Check for floating UI
const floatingIcon = document.querySelector('#complyze-floating-icon');
const sidebar = document.querySelector('#complyze-sidebar');

console.log("Floating Icon:", floatingIcon ? 'Present' : 'Missing');
console.log("Sidebar:", sidebar ? 'Present' : 'Missing');

// Force reload floating UI
if (window.ComplyzeFloatingUI) {
    console.log("🔄 ComplyzeFloatingUI class found - attempting to create new instance");
    new window.ComplyzeFloatingUI();
} else {
    console.log("❌ ComplyzeFloatingUI class not found");
}

// Check if floating-ui.js loaded properly
if (typeof ComplyzeFloatingUI !== 'undefined') {
    console.log("✅ ComplyzeFloatingUI class is available");
} else {
    console.log("❌ ComplyzeFloatingUI class is NOT available");
}

// Manual UI creation if needed
function forceCreateFloatingUI() {
    console.log("🚀 Manually creating floating UI...");
    
    // Remove existing elements if any
    const existingIcon = document.querySelector('#complyze-floating-icon');
    const existingSidebar = document.querySelector('#complyze-sidebar');
    
    if (existingIcon) existingIcon.remove();
    if (existingSidebar) existingSidebar.remove();
    
    // Create floating icon manually
    const floatingIcon = document.createElement('div');
    floatingIcon.id = 'complyze-floating-icon';
    floatingIcon.innerHTML = `
        <div class="complyze-icon-content">
            <img src="${chrome.runtime.getURL('icons/icon-32.png')}" alt="Complyze" />
        </div>
    `;
    
    floatingIcon.style.cssText = `
        position: fixed;
        top: 40%;
        right: 30px;
        transform: translateY(-50%);
        width: 50px;
        height: 50px;
        background: #0E1E36;
        border: 2px solid rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        cursor: pointer;
        z-index: 999999;
        box-shadow: 
            0 0 0 1px rgba(255, 255, 255, 0.2),
            0 0 10px rgba(255, 255, 255, 0.1),
            0 0 20px rgba(255, 255, 255, 0.05),
            0 4px 20px rgba(0, 0, 0, 0.3);
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
    `;
    
    // Style the image
    const img = floatingIcon.querySelector('img');
    img.style.cssText = `
        width: 24px;
        height: 24px;
        object-fit: contain;
    `;
    
    // Add hover effect
    floatingIcon.addEventListener('mouseenter', () => {
        floatingIcon.style.transform = 'translateY(-50%) scale(1.1)';
    });
    
    floatingIcon.addEventListener('mouseleave', () => {
        floatingIcon.style.transform = 'translateY(-50%) scale(1)';
    });
    
    // Add click handler
    floatingIcon.addEventListener('click', () => {
        alert('Complyze floating UI manually created! Extension is working.');
    });
    
    document.body.appendChild(floatingIcon);
    console.log("✅ Floating icon manually created");
}

// Expose manual creation function globally
window.forceCreateFloatingUI = forceCreateFloatingUI;
console.log("💡 You can manually create the UI by running: forceCreateFloatingUI()"); 
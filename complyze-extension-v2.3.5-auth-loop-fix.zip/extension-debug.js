// Extension Debug & Diagnostic Script
console.log('Complyze Extension Debug: Script starting...');

// Test Chrome extension API availability
function testExtensionAPIs() {
  console.log('=== Complyze Extension API Tests ===');
  
  // Test chrome object
  if (typeof chrome !== 'undefined') {
    console.log('✅ Chrome object available');
    
    // Test runtime
    if (chrome.runtime) {
      console.log('✅ Chrome runtime available');
      console.log('Extension ID:', chrome.runtime.id);
      
      // Test if we can send messages
      try {
        chrome.runtime.sendMessage({ type: 'debug_test' }, (response) => {
          if (chrome.runtime.lastError) {
            console.log('❌ Message test failed:', chrome.runtime.lastError.message);
          } else {
            console.log('✅ Message system working:', response);
          }
        });
      } catch (error) {
        console.log('❌ Message test error:', error);
      }
    } else {
      console.log('❌ Chrome runtime not available');
    }
    
    // Test storage
    if (chrome.storage) {
      console.log('✅ Chrome storage available');
      
      chrome.storage.local.get(['test_key'], (result) => {
        if (chrome.runtime.lastError) {
          console.log('❌ Storage test failed:', chrome.runtime.lastError.message);
        } else {
          console.log('✅ Storage test passed');
        }
      });
    } else {
      console.log('❌ Chrome storage not available');
    }
    
    // Test tabs
    if (chrome.tabs) {
      console.log('✅ Chrome tabs API available');
    } else {
      console.log('❌ Chrome tabs API not available');
    }
    
    // Test scripting
    if (chrome.scripting) {
      console.log('✅ Chrome scripting API available (MV3)');
    } else {
      console.log('❌ Chrome scripting API not available');
    }
    
  } else {
    console.log('❌ Chrome object not available - extension context issue');
  }
}

// Test DOM and page context
function testPageContext() {
  console.log('=== Page Context Tests ===');
  console.log('Current URL:', window.location.href);
  console.log('Document ready state:', document.readyState);
  
  // Test if we can find typical input elements
  const inputs = document.querySelectorAll('textarea, div[contenteditable="true"], input[type="text"]');
  console.log('Found', inputs.length, 'potential input elements');
  
  // Test if we can create elements
  try {
    const testDiv = document.createElement('div');
    testDiv.id = 'complyze-debug-test';
    testDiv.style.display = 'none';
    document.body.appendChild(testDiv);
    console.log('✅ DOM manipulation working');
    testDiv.remove();
  } catch (error) {
    console.log('❌ DOM manipulation failed:', error);
  }
}

// Run tests
testExtensionAPIs();
testPageContext();

// Export for other scripts to use
if (typeof window !== 'undefined') {
  window.ComplyzeDebug = {
    testExtensionAPIs,
    testPageContext
  };
} 
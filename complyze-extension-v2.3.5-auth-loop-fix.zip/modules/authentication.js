// Authentication module for Complyze extension
import { CONFIG } from './config.js';

export class AuthManager {
  constructor() {
    this.apiBase = CONFIG.API.PRODUCTION_BASE;
    this.accessToken = null;
    this.user = null;
    this.lastTokenVerification = null;
  }

  async init() {
    // Load stored auth data
    const stored = await chrome.storage.local.get(['accessToken', 'user', 'refreshToken', 'loginTime']);
    this.accessToken = stored.accessToken || null;
    this.user = stored.user || null;
    this.refreshToken = stored.refreshToken || null;
    this.loginTime = stored.loginTime || null;
    
    if (this.accessToken && this.user) {
      console.log('Complyze: Restored authentication from storage for user:', this.user.email);
      console.log('Complyze: Login time:', this.loginTime ? new Date(this.loginTime).toISOString() : 'unknown');
    } else {
      console.log('Complyze: No stored authentication found');
    }
  }

  async verifyToken() {
    if (!this.accessToken) return false;
    
    try {
      const response = await fetch(`${this.apiBase}/auth/check`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.accessToken}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Origin': 'chrome-extension://' + chrome.runtime.id
        },
        credentials: 'include',
        signal: AbortSignal.timeout(CONFIG.TIMEOUTS.TOKEN_VERIFICATION)
      });
      
      const data = await response.json();
      console.log('Complyze: Token verification response:', data);
      
      if (response.ok && data.authenticated) {
        this.lastTokenVerification = Date.now();
        // Update user data if returned
        if (data.user) {
          this.user = data.user;
          await chrome.storage.local.set({ user: this.user });
        }
        console.log('Complyze: Token verification successful');
        return true;
      } else if (response.status === 401 || response.status === 403 || !data.authenticated) {
        // Token is invalid, clear auth
        console.log('Complyze: Token is invalid, clearing auth');
        await this.clearAuth();
        return false;
      }
      console.log('Complyze: Token verification failed with status:', response.status);
      return false;
    } catch (error) {
      console.error('Complyze: Token verification failed:', error);
      // Don't clear auth on network errors, only on explicit auth failures
      return false;
    }
  }

  async clearAuth() {
    this.accessToken = null;
    this.user = null;
    this.lastTokenVerification = null;
    await chrome.storage.local.remove(['accessToken', 'user', 'refreshToken', 'loginTime']);
    console.log('Complyze: Authentication cleared');
  }

  async checkUserAuth() {
    if (!this.accessToken || !this.user) {
      return { isAuthenticated: false, needsAuth: true };
    }

    // Check if token verification is recent enough
    const now = Date.now();
    if (!this.lastTokenVerification || 
        (now - this.lastTokenVerification) > CONFIG.INTERVALS.TOKEN_VERIFICATION) {
      const isValid = await this.verifyToken();
      if (!isValid) {
        return { isAuthenticated: false, needsAuth: true };
      }
    }

    return { isAuthenticated: true, user: this.user };
  }

  async login(email, password) {
    try {
      console.log('Complyze: Attempting login for:', email);
      
      const response = await fetch(`${this.apiBase}/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Origin': 'chrome-extension://' + chrome.runtime.id
        },
        credentials: 'include', // Important: Include cookies/session data
        body: JSON.stringify({ email, password }),
        signal: AbortSignal.timeout(CONFIG.TIMEOUTS.API_REQUEST)
      });

      console.log('Complyze: Login response status:', response.status, response.statusText);
      console.log('Complyze: Response headers:', [...response.headers.entries()]);

      const data = await response.json();
      console.log('Complyze: Login response data:', data);

      if (!response.ok) {
        console.error('Complyze: Login failed with status:', response.status);
        throw new Error(data.error || data.details || 'Login failed');
      }

      // Handle the exact same response format as the website API
      if (!data.success || !data.access_token || !data.user) {
        console.error('Complyze: Invalid response format - missing required fields');
        console.error('Expected: success, access_token, user. Got:', Object.keys(data));
        throw new Error('Invalid response format from server');
      }

      // Store auth data using the exact same format as the website
      this.accessToken = data.access_token;
      this.user = data.user;
      this.lastTokenVerification = Date.now();

      await chrome.storage.local.set({
        accessToken: this.accessToken,
        user: this.user,
        refreshToken: data.refresh_token, // Also store refresh token like the website
        loginTime: Date.now()
      });

      console.log('Complyze: Login successful for user:', this.user.email);
      console.log('Complyze: User plan:', this.user.plan);
      console.log('Complyze: Auth data stored successfully');

      return { success: true, user: this.user };

    } catch (error) {
      console.error('Complyze: Login error:', error);
      console.error('Complyze: Error details:', {
        name: error.name,
        message: error.message,
        stack: error.stack
      });
      return { success: false, error: error.message };
    }
  }

  async signup(email, password, fullName) {
    try {
      console.log('Complyze: Attempting signup for:', email);
      
      const response = await fetch(`${this.apiBase}/auth/signup`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Origin': 'chrome-extension://' + chrome.runtime.id
        },
        credentials: 'include', // Important: Include cookies/session data
        body: JSON.stringify({ 
          email, 
          password, 
          full_name: fullName 
        }),
        signal: AbortSignal.timeout(CONFIG.TIMEOUTS.API_REQUEST)
      });

      console.log('Complyze: Signup response status:', response.status, response.statusText);
      console.log('Complyze: Response headers:', [...response.headers.entries()]);

      const data = await response.json();
      console.log('Complyze: Signup response data:', data);

      if (!response.ok) {
        console.error('Complyze: Signup failed with status:', response.status);
        throw new Error(data.error || data.details || 'Signup failed');
      }

      // Check if this is a successful signup (may require email verification)
      if (data.success) {
        // If access_token is provided, user is automatically logged in
        if (data.access_token && data.user) {
          this.accessToken = data.access_token;
          this.user = data.user;
          this.lastTokenVerification = Date.now();

          await chrome.storage.local.set({
            accessToken: this.accessToken,
            user: this.user,
            refreshToken: data.refresh_token,
            loginTime: Date.now()
          });

          console.log('Complyze: Signup with auto-login successful for user:', this.user.email);
          return { success: true, user: this.user, auto_login: true };
        } else {
          // Signup successful but email verification required
          console.log('Complyze: Signup successful, email verification required');
          return { 
            success: true, 
            auto_login: false,
            message: data.message || 'Account created successfully! Please check your email for verification.'
          };
        }
      } else {
        throw new Error(data.error || 'Signup failed');
      }

    } catch (error) {
      console.error('Complyze: Signup error:', error);
      console.error('Complyze: Error details:', {
        name: error.name,
        message: error.message,
        stack: error.stack
      });
      return { success: false, error: error.message };
    }
  }

  async logout() {
    try {
      if (this.accessToken) {
        await fetch(`${this.apiBase}/auth/logout`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.accessToken}`
          },
          signal: AbortSignal.timeout(CONFIG.TIMEOUTS.API_REQUEST)
        });
      }
    } catch (error) {
      console.error('Complyze: Logout request failed:', error);
    } finally {
      await this.clearAuth();
      console.log('Complyze: User logged out');
    }
  }

  async syncFromWebsite() {
    try {
      const dashboardTabs = await chrome.tabs.query({ 
        url: [`${this.apiBase.replace('/api', '')}/dashboard*`] 
      });
      
      if (dashboardTabs.length === 0) {
        console.log('Complyze: No dashboard tabs found for auth sync');
        return;
      }

      const results = await chrome.scripting.executeScript({
        target: { tabId: dashboardTabs[0].id },
        func: () => {
          const authData = localStorage.getItem('complyze_auth');
          return authData ? JSON.parse(authData) : null;
        }
      });

      if (results?.[0]?.result) {
        const { access_token, user } = results[0].result;
        if (access_token && user) {
          await this.handleAuthSyncFromWebsite(access_token, user);
        }
      }
    } catch (error) {
      console.error('Complyze: Auth sync from website failed:', error);
    }
  }

  async handleAuthSyncFromWebsite(token, user) {
    this.accessToken = token;
    this.user = user;
    this.lastTokenVerification = Date.now();

    await chrome.storage.local.set({
      accessToken: this.accessToken,
      user: this.user
    });

    console.log('Complyze: Auth synced from website for user:', user.email);
  }

  getAuthStatus() {
    return {
      isAuthenticated: !!(this.accessToken && this.user),
      user: this.user
    };
  }

  async setAuthData(data) {
    if (data.accessToken) {
      this.accessToken = data.accessToken;
    }
    if (data.user) {
      this.user = data.user;
    }
    
    await chrome.storage.local.set({
      accessToken: this.accessToken,
      user: this.user
    });
    
    console.log('Complyze: Auth data updated successfully');
  }
} 
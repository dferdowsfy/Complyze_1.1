// AI Optimization module for Complyze extension
import { CONFIG } from './config.js';
import { DataRedactor } from './dataRedaction.js';

export class AIOptimizer {
  constructor() {
    this.apiKey = null;
  }

  async loadApiKey() {
    try {
      const stored = await chrome.storage.local.get(['openrouter_api_key']);
      if (stored.openrouter_api_key) {
        this.apiKey = stored.openrouter_api_key;
        console.log('Complyze: OpenRouter API key loaded from storage');
        return true;
      }
      
      console.warn('Complyze: No OpenRouter API key found in storage');
      return false;
    } catch (error) {
      console.error('Complyze: Error loading API key:', error);
      return false;
    }
  }

  async enhancePromptWithAI(originalPrompt) {
    try {
      // Load API key if not already loaded
      if (!this.apiKey) {
        const keyLoaded = await this.loadApiKey();
        if (!keyLoaded) {
          return this.createFallbackOptimization(originalPrompt);
        }
      }

      const startTime = Date.now();

      // Step 1: Clean and analyze the prompt
      const { cleaned, sensitiveDataRemoved, complianceFrameworks, aiRiskIndicators } = 
        DataRedactor.removeSensitiveData(originalPrompt);
      
      const intent = DataRedactor.analyzePromptIntent(originalPrompt);
      const riskLevel = DataRedactor.calculateRiskLevel(sensitiveDataRemoved, aiRiskIndicators);

      // Step 2: Create optimization prompt
      const optimizationPrompt = this.createOptimizationPrompt(cleaned, intent);

      // Step 3: Call AI API
      const aiResponse = await this.callOpenRouterAPI(optimizationPrompt);
      
      if (!aiResponse) {
        return this.createFallbackOptimization(originalPrompt);
      }

      // Step 4: Parse response
      const processingTime = Date.now() - startTime;
      const result = this.parseOptimizationResponse(
        aiResponse, 
        originalPrompt, 
        cleaned, 
        intent, 
        sensitiveDataRemoved, 
        complianceFrameworks, 
        aiRiskIndicators
      );

      result.processing_time = processingTime;
      return result;

    } catch (error) {
      console.error('Complyze: AI enhancement error:', error);
      return this.createFallbackOptimization(originalPrompt);
    }
  }

  createOptimizationPrompt(cleanedPrompt, intent) {
    const basePrompt = `Optimize this ${intent} prompt for clarity, professionalism, and effectiveness. Maintain the original meaning and intent while improving structure and language.

Original prompt: "${cleanedPrompt}"

Provide optimization in this exact JSON format:
{
  "optimized_prompt": "Your improved version here",
  "improvements": ["list", "of", "specific", "improvements", "made"],
  "confidence": 0.85
}`;

    return basePrompt;
  }

  async callOpenRouterAPI(prompt) {
    try {
      const response = await fetch(CONFIG.API.OPENROUTER.BASE_URL, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': 'https://complyze.co',
          'X-Title': 'Complyze AI Optimization'
        },
        body: JSON.stringify({
          model: CONFIG.API.OPENROUTER.MODEL,
          messages: [
            {
              role: 'system',
              content: 'You are an expert prompt optimizer focused on clarity, professionalism, and effectiveness. Always respond with valid JSON only.'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          max_tokens: 1500,
          temperature: 0.3
        }),
        signal: AbortSignal.timeout(CONFIG.TIMEOUTS.API_REQUEST)
      });

      if (!response.ok) {
        console.error(`Complyze: OpenRouter API error: ${response.status} ${response.statusText}`);
        return null;
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content;
      
      if (!content) {
        console.error('Complyze: No content in OpenRouter response');
        return null;
      }

      // Parse JSON response
      try {
        return JSON.parse(content);
      } catch (parseError) {
        console.error('Complyze: Failed to parse OpenRouter JSON response:', parseError);
        // Try to extract JSON from response if it's wrapped in text
        const jsonMatch = content.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          return JSON.parse(jsonMatch[0]);
        }
        return null;
      }

    } catch (error) {
      console.error('Complyze: OpenRouter API call failed:', error);
      return null;
    }
  }

  parseOptimizationResponse(aiContent, originalPrompt, cleanedPrompt, intent, sensitiveDataRemoved, complianceFrameworks, aiRiskIndicators) {
    const riskLevel = DataRedactor.calculateRiskLevel(sensitiveDataRemoved, aiRiskIndicators);
    
    // Base result structure
    const result = {
      original_prompt: originalPrompt,
      risk_level: riskLevel,
      sensitive_data_removed: sensitiveDataRemoved,
      compliance_frameworks: complianceFrameworks,
      ai_risk_indicators: aiRiskIndicators,
      intent: intent,
      optimization_successful: false,
      optimized_prompt: null,
      improvements: [],
      confidence: 0
    };

    if (aiContent && aiContent.optimized_prompt) {
      result.optimization_successful = true;
      result.optimized_prompt = aiContent.optimized_prompt;
      result.improvements = aiContent.improvements || [];
      result.confidence = aiContent.confidence || 0.8;
      
      console.log('Complyze: AI optimization successful');
    } else {
      // Fallback to local optimization
      result.optimized_prompt = this.createLocalOptimization(cleanedPrompt, intent);
      result.improvements = ['Applied local optimization due to AI processing limitations'];
      result.confidence = 0.6;
      
      console.log('Complyze: Using local optimization fallback');
    }

    return result;
  }

  createLocalOptimization(prompt, intent) {
    // Basic local optimization patterns
    let optimized = prompt;
    
    // Capitalize first letter
    optimized = optimized.charAt(0).toUpperCase() + optimized.slice(1);
    
    // Ensure proper punctuation
    if (!optimized.match(/[.!?]$/)) {
      optimized += '.';
    }
    
    // Intent-specific improvements
    switch (intent) {
      case 'creation':
        if (!optimized.toLowerCase().includes('please')) {
          optimized = `Please ${optimized.toLowerCase()}`;
        }
        break;
      case 'analysis':
        if (!optimized.toLowerCase().includes('analyze') && !optimized.toLowerCase().includes('review')) {
          optimized = `Please analyze the following: ${optimized}`;
        }
        break;
      case 'explanation':
        if (!optimized.toLowerCase().includes('explain') && !optimized.includes('?')) {
          optimized = `Could you explain ${optimized.toLowerCase()}?`;
        }
        break;
    }
    
    return optimized;
  }

  createFallbackOptimization(originalPrompt) {
    const { cleaned, sensitiveDataRemoved, complianceFrameworks, aiRiskIndicators } = 
      DataRedactor.removeSensitiveData(originalPrompt);
    
    const intent = DataRedactor.analyzePromptIntent(originalPrompt);
    const riskLevel = DataRedactor.calculateRiskLevel(sensitiveDataRemoved, aiRiskIndicators);
    
    return {
      original_prompt: originalPrompt,
      risk_level: riskLevel,
      sensitive_data_removed: sensitiveDataRemoved,
      compliance_frameworks: complianceFrameworks,
      ai_risk_indicators: aiRiskIndicators,
      intent: intent,
      optimization_successful: false,
      optimized_prompt: this.createLocalOptimization(cleaned, intent),
      improvements: ['Local optimization applied', 'AI optimization unavailable'],
      confidence: 0.5,
      processing_time: 0
    };
  }

  async handleRealTimeAnalysis(promptData) {
    try {
      const { cleaned, sensitiveDataRemoved, complianceFrameworks, aiRiskIndicators } = 
        DataRedactor.removeSensitiveData(promptData.prompt);
      
      const intent = DataRedactor.analyzePromptIntent(promptData.prompt);
      const riskLevel = DataRedactor.calculateRiskLevel(sensitiveDataRemoved, aiRiskIndicators);
      
      return {
        risk_level: riskLevel,
        sensitive_data_count: sensitiveDataRemoved.length,
        compliance_frameworks: complianceFrameworks,
        ai_risk_indicators: aiRiskIndicators,
        intent: intent,
        safe_prompt: DataRedactor.generateSafePrompt(promptData.prompt),
        recommendations: this.generateRecommendations(riskLevel, sensitiveDataRemoved)
      };
    } catch (error) {
      console.error('Complyze: Real-time analysis error:', error);
      return {
        risk_level: 'unknown',
        sensitive_data_count: 0,
        compliance_frameworks: [],
        ai_risk_indicators: [],
        intent: 'general',
        safe_prompt: promptData.prompt,
        recommendations: []
      };
    }
  }

  generateRecommendations(riskLevel, sensitiveDataRemoved) {
    const recommendations = [];
    
    if (riskLevel === 'high') {
      recommendations.push('Consider reviewing this prompt before submitting');
      recommendations.push('Remove or replace specific identifiers with general terms');
    }
    
    if (sensitiveDataRemoved.some(item => item.includes('Medical') || item.includes('Patient'))) {
      recommendations.push('HIPAA compliance required - ensure no PHI is shared');
    }
    
    if (sensitiveDataRemoved.some(item => item.includes('API key') || item.includes('Token'))) {
      recommendations.push('Never share API keys or authentication tokens');
    }
    
    return recommendations;
  }
} 
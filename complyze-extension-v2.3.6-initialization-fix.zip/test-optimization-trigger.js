// Test file to debug why prompt optimization isn't triggering
// Run this in the browser console on a ChatGPT/Claude page

async function testOptimizationTrigger() {
  console.log('🔍 === COMPLYZE OPTIMIZATION TRIGGER TEST ===');
  
  // Test 1: Check if extension is loaded
  console.log('\n📦 STEP 1: Extension Status');
  const extensionId = chrome.runtime.id;
  console.log('Extension ID:', extensionId);
  
  // Test 2: Check if background script is responding
  console.log('\n📡 STEP 2: Background Script Communication');
  try {
    const response = await chrome.runtime.sendMessage({ type: 'debug_test' });
    console.log('✅ Background script response:', response);
  } catch (error) {
    console.error('❌ Background script not responding:', error);
    return;
  }
  
  // Test 3: Check authentication status
  console.log('\n🔐 STEP 3: Authentication Status');
  try {
    const authStatus = await chrome.runtime.sendMessage({ type: 'get_auth_status' });
    console.log('Auth status:', authStatus);
    if (!authStatus.isAuthenticated) {
      console.warn('⚠️ User not authenticated - this will prevent optimization');
    }
  } catch (error) {
    console.error('❌ Failed to check auth status:', error);
  }
  
  // Test 4: Test sensitive data detection patterns
  console.log('\n🔍 STEP 4: Testing Sensitive Data Detection');
  
  const testPrompts = [
    {
      name: 'Email Test',
      prompt: 'My email is john.doe@company.com and I need help.',
      expectedTrigger: true
    },
    {
      name: 'SSN Test', 
      prompt: 'My SSN is 123-45-6789 for verification.',
      expectedTrigger: true
    },
    {
      name: 'API Key Test',
      prompt: 'Use this API key: sk-proj-abc123def456ghi789jklmnop',
      expectedTrigger: true
    },
    {
      name: 'Phone Test',
      prompt: 'Call me at (555) 123-4567 tomorrow.',
      expectedTrigger: true
    },
    {
      name: 'Clean Test',
      prompt: 'What is the capital of France?',
      expectedTrigger: false
    }
  ];
  
  // Test each prompt pattern
  for (const test of testPrompts) {
    console.log(`\n   Testing: ${test.name}`);
    console.log(`   Prompt: "${test.prompt}"`);
    
    // Simulate the local analysis that content script does
    const detectedPII = [];
    
    // Email detection
    if (/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g.test(test.prompt)) {
      detectedPII.push('email');
    }
    
    // SSN detection  
    if (/\b\d{3}-?\d{2}-?\d{4}\b/g.test(test.prompt)) {
      detectedPII.push('ssn');
    }
    
    // API key detection
    if (/\bsk-[a-zA-Z0-9]{32,}\b/g.test(test.prompt)) {
      detectedPII.push('api_key');
    }
    
    // Phone detection
    if (/(\+?1[-.\s]?)?\(?([0-9]{3})\)?[-.\s]?([0-9]{3})[-.\s]?([0-9]{4})/g.test(test.prompt)) {
      detectedPII.push('phone');
    }
    
    const shouldTrigger = detectedPII.length > 0;
    const riskLevel = detectedPII.includes('ssn') || detectedPII.includes('api_key') ? 'critical' : 
                     detectedPII.length > 0 ? 'high' : 'low';
    
    console.log(`   Detected PII: [${detectedPII.join(', ')}]`);
    console.log(`   Risk Level: ${riskLevel}`);
    console.log(`   Should Trigger: ${shouldTrigger} (Expected: ${test.expectedTrigger})`);
    
    if (shouldTrigger !== test.expectedTrigger) {
      console.warn(`   ⚠️ MISMATCH: Expected ${test.expectedTrigger}, got ${shouldTrigger}`);
    } else {
      console.log(`   ✅ Detection working correctly`);
    }
  }
  
  // Test 5: Test actual background optimization trigger
  console.log('\n🚀 STEP 5: Testing Background Optimization Trigger');
  
  const sensitivePrompt = 'My email is test@example.com and my API key is sk-proj-test123456789';
  console.log('Testing with prompt:', sensitivePrompt);
  
  try {
    console.log('Sending analyze_prompt message...');
    const startTime = Date.now();
    
    const analysisResponse = await chrome.runtime.sendMessage({
      type: 'analyze_prompt',
      payload: {
        prompt: sensitivePrompt,
        platform: 'chatgpt',
        url: window.location.href,
        timestamp: new Date().toISOString(),
        triggerOptimization: true
      }
    });
    
    const endTime = Date.now();
    console.log(`Response received in ${endTime - startTime}ms`);
    console.log('Analysis response:', analysisResponse);
    
    if (analysisResponse && analysisResponse.success) {
      console.log('✅ Background analysis succeeded');
      
      if (analysisResponse.optimizedPrompt) {
        console.log('✅ AI optimization completed!');
        console.log('Optimized prompt preview:', analysisResponse.optimizedPrompt.substring(0, 100) + '...');
      } else {
        console.warn('⚠️ No optimized prompt in response');
        console.log('Analysis data:', analysisResponse.analysis);
      }
    } else {
      console.error('❌ Background analysis failed:', analysisResponse);
    }
    
  } catch (error) {
    console.error('❌ Failed to test background optimization:', error);
  }
  
  // Test 6: Check OpenRouter API configuration
  console.log('\n🔑 STEP 6: API Configuration Check');
  try {
    const stored = await chrome.storage.local.get(['openrouter_api_key']);
    console.log('OpenRouter API key status:', stored.openrouter_api_key ? 'Present' : 'Missing');
    
    if (!stored.openrouter_api_key) {
      console.warn('⚠️ No OpenRouter API key found in storage - AI optimization will use default key');
    }
  } catch (error) {
    console.error('❌ Failed to check API configuration:', error);
  }
  
  console.log('\n🎯 === TEST SUMMARY ===');
  console.log('If optimization is not working:');
  console.log('1. Check that you are authenticated (Step 3)');
  console.log('2. Verify sensitive data detection patterns (Step 4)');
  console.log('3. Check background script response (Step 5)');
  console.log('4. Ensure API key is configured (Step 6)');
  console.log('\nTry typing a prompt with an email address on this page to trigger optimization.');
}

// Also create a simple trigger test
function quickTriggerTest() {
  console.log('🔥 Quick Trigger Test - Type this in the prompt box:');
  const testPrompt = 'My email is john.doe@company.com, please help me write a report.';
  console.log(`"${testPrompt}"`);
  console.log('This should trigger immediate blocking and show AI optimization progress.');
  
  // Try to find and fill a prompt input
  const inputs = document.querySelectorAll('textarea, input[type="text"]');
  const promptInput = Array.from(inputs).find(input => 
    input.placeholder?.toLowerCase().includes('message') ||
    input.placeholder?.toLowerCase().includes('prompt') ||
    input.id?.toLowerCase().includes('prompt') ||
    input.name?.toLowerCase().includes('prompt')
  );
  
  if (promptInput) {
    console.log('Found prompt input, filling with test data...');
    promptInput.focus();
    promptInput.value = testPrompt;
    promptInput.dispatchEvent(new Event('input', { bubbles: true }));
    console.log('✅ Test prompt inserted. Watch for blocking behavior.');
  } else {
    console.log('❌ Could not find prompt input on this page.');
  }
}

// Make functions available globally
window.testOptimizationTrigger = testOptimizationTrigger;
window.quickTriggerTest = quickTriggerTest;

console.log('🛠️ Optimization debug tools loaded!');
console.log('Run: testOptimizationTrigger() for full test');
console.log('Run: quickTriggerTest() for quick test'); 
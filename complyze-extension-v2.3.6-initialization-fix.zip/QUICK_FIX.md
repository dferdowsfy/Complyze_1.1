# Quick Fix for Complyze Extension Not Working

## Problem
Extension loads but doesn't trigger or popup doesn't work.

## Most Common Cause: Authentication Issue

### Solution 1: Authenticate the Extension
1. Go to https://complyze.co/dashboard
2. Log in with your account
3. Click the Complyze extension icon in Chrome toolbar
4. Follow authentication prompts

### Solution 2: Check Background Script Errors
1. Go to `chrome://extensions/`
2. Find "Complyze - AI Prompt Security & Optimization"
3. Click "Inspect views: service worker"
4. Check Console tab for red errors
5. If you see errors, screenshot and report them

### Solution 3: Force Reload Extension
1. Go to `chrome://extensions/`
2. Toggle the extension OFF and ON
3. Or click the refresh/reload icon
4. Try clicking the extension icon again

### Solution 4: Check Extension Popup
1. Right-click the Complyze extension icon
2. Select "Inspect popup" if available
3. Check for errors in the popup's console

### Solution 5: Test on a Supported Site
1. Go to https://chat.openai.com or https://claude.ai
2. Try typing a message with sensitive info like "My email is john@example.com"
3. The extension should trigger automatically

## Debug Commands

If popup appears but doesn't work, open popup and run in its console:

```javascript
// Test authentication
chrome.storage.local.get(['accessToken', 'user'], (result) => {
  console.log('Auth status:', result);
});

// Test background script communication
chrome.runtime.sendMessage({type: 'debug_test'}, (response) => {
  console.log('Background response:', response);
});
```

## Red Flags to Look For

❌ **Console Errors:**
- "Cannot access chrome.runtime"
- "Extension context invalidated"
- "Failed to load resource"
- "Uncaught TypeError"

❌ **Authentication Errors:**
- "No access token"
- "User not authenticated"
- "Failed to verify token"

❌ **Network Errors:**
- "Failed to fetch"
- "CORS error"
- "Network request failed"

## If Nothing Works

1. **Completely remove and reinstall the extension:**
   - Go to chrome://extensions/
   - Click "Remove" for Complyze
   - Load the extension again

2. **Check Chrome version:**
   - Must be Chrome 88+ for Manifest V3 support

3. **Contact support with:**
   - Screenshot of console errors
   - Chrome version
   - Operating system
   - Steps that led to the issue 
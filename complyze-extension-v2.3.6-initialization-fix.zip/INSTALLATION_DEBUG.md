# Complyze Chrome Extension - Installation & Debug Guide

## Quick Installation Steps

1. **Open Chrome Extensions Page**
   - Go to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top right)

2. **Load Extension**
   - Click "Load unpacked"
   - Select the `complyze-extension-v2` folder
   - Extension should appear in the list

3. **Verify Installation**
   - Look for Complyze icon in Chrome toolbar
   - Click the icon to open popup
   - Check for any error messages

## Common Issues & Solutions

### Issue 1: Extension Not Loading
**Symptoms:** Extension doesn't appear in chrome://extensions/

**Solutions:**
1. Check manifest.json syntax:
   ```bash
   python3 -m json.tool manifest.json
   ```
2. Verify all required files exist:
   - manifest.json
   - background.js
   - content.js
   - popup.html
   - popup.js
   - All icon files in icons/ folder

### Issue 2: Background Script Errors
**Symptoms:** Extension loads but doesn't work

**Solutions:**
1. Open Chrome DevTools for background script:
   - Go to `chrome://extensions/`
   - Find Complyze extension
   - Click "Inspect views: background page"
   - Check Console for errors

2. Test background script:
   ```javascript
   // In background script console
   chrome.runtime.sendMessage({type: 'debug_test'}, console.log);
   ```

### Issue 3: Content Script Not Injecting
**Symptoms:** Extension doesn't detect prompts on websites

**Solutions:**
1. Check content script injection:
   - Open any supported website (e.g., chat.openai.com)
   - Open DevTools (F12)
   - Look for "Complyze: Content script starting" in console

2. Test content script manually:
   ```javascript
   // In website console
   window.ComplyzeDebug.testExtensionAPIs();
   ```

### Issue 4: Popup Not Working
**Symptoms:** Clicking extension icon shows blank popup

**Solutions:**
1. Right-click extension icon → "Inspect popup"
2. Check popup console for errors
3. Verify popup.html loads correctly

## Debug Tools

### 1. Extension Debug Script
Load the debug script in any webpage console:
```javascript
// This will test all extension APIs
window.ComplyzeDebug.testExtensionAPIs();
window.ComplyzeDebug.testPageContext();
```

### 2. Background Script Debug
In background script console:
```javascript
// Test message system
chrome.runtime.sendMessage({type: 'debug_test'}, console.log);

// Check storage
chrome.storage.local.get(null, console.log);

// Test API endpoints
complyzeBackground.apiBase;
complyzeBackground.dashboardUrl;
```

### 3. Content Script Debug
In website console:
```javascript
// Check if content script loaded
console.log('Content script loaded:', typeof PromptWatcher !== 'undefined');

// Test prompt detection
document.querySelectorAll('textarea, div[contenteditable="true"]');
```

## Manifest V3 Compatibility

This extension uses Manifest V3. Key differences from V2:
- Service worker instead of background page
- `chrome.scripting` instead of `chrome.tabs.executeScript`
- More restrictive CSP

## Security Notes

- API keys are loaded from secure storage, not hardcoded
- All external API calls go through production endpoints
- No sensitive data is logged in production

## Testing Checklist

- [ ] Extension loads without errors
- [ ] Background script responds to messages
- [ ] Content script injects on supported sites
- [ ] Popup opens and displays correctly
- [ ] Authentication flow works
- [ ] Prompt detection works on test sites
- [ ] No console errors in any context

## Support

If issues persist:
1. Check Chrome version (requires Chrome 88+)
2. Disable other extensions temporarily
3. Try in incognito mode
4. Clear extension storage: `chrome.storage.local.clear()`

## File Structure
```
complyze-extension-v2/
├── manifest.json          # Extension configuration
├── background.js          # Service worker (main logic)
├── content.js            # Injected into web pages
├── popup.html            # Extension popup UI
├── popup.js              # Popup functionality
├── injectUI.js           # UI injection script
├── extension-debug.js    # Debug utilities
├── icons/                # Extension icons
└── INSTALLATION_DEBUG.md # This file
``` 